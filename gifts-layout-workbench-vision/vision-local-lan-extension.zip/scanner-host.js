(() => {
  // vision/orders/approval-file-list.mjs
  var ORDER_LIST_MIN = 1e6;
  var ORDER_LIST_MAX = 9999999;
  var ORDER_LIST_MAX_COUNT = 1e6;
  var ORDER_LIST_MAX_BYTES = 2e7;
  function explicitListOrderUrl(order) {
    if (!Number.isSafeInteger(order) || order < ORDER_LIST_MIN || order > ORDER_LIST_MAX)
      throw Error("MANUAL_ORDER_LIST_ID_INVALID");
    return "http://testgifts.local/private/order/" + order;
  }
  function parseOrderListText(text) {
    if (typeof text !== "string" || new TextEncoder().encode(text).length > ORDER_LIST_MAX_BYTES)
      throw Error("MANUAL_ORDER_LIST_TOO_LARGE");
    const seen = /* @__PURE__ */ new Set(), numbers = [];
    const rows = text.replace(/^\uFEFF/, "").split(/\r\n|\n|\r/);
    let duplicates = 0, empty = 0;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i].trim();
      if (!row) {
        empty++;
        continue;
      }
      if (!/^[0-9]{7}$/.test(row))
        throw Error("MANUAL_ORDER_LIST_INVALID_LINE_" + (i + 1));
      const id = Number(row);
      if (id < ORDER_LIST_MIN || id > ORDER_LIST_MAX)
        throw Error("MANUAL_ORDER_LIST_ID_INVALID");
      if (seen.has(id)) {
        duplicates++;
        continue;
      }
      if (numbers.length >= ORDER_LIST_MAX_COUNT)
        throw Error("MANUAL_ORDER_LIST_TOO_MANY_NUMBERS");
      seen.add(id);
      numbers.push(id);
    }
    if (!numbers.length) throw Error("MANUAL_ORDER_LIST_EMPTY");
    return { numbers, duplicates, empty, source_lines: rows.length };
  }

  // vision/orders/discussion-probe.mjs
  var TOPICS = Object.freeze({
    positive_min: /(?:тонк(?:ая|ие|их|ий)|толщин[ауы]|мелки[ех]|перемычк[аие]|линия\s+тонк)/i,
    negative_min: /(?:пробел[ауы]?|выворотк|зазор[ауы]?|просвет[ауы]?)/i,
    out_of_field: /(?:вне\s+(?:поля|зоны)|за\s+(?:пределы|границ)|выходит\s+за|охранн(?:ое|ая)\s+поле)/i,
    color: /(?:\brgb\b|\bcmyk\b|\bpantone\b|цветоделени|цветов(?:ое|ые)|цвет\s+не)/i,
    font: /(?:шрифт[ауы]?|в\s+кривы[ех]|текст\s+не\s+перев)/i,
    raster_resolution: /(?:разрешени[ея]|dpi|пикселизац|растров(?:ый|ое)|пиксел[ья])/i,
    gradient_transparency: /(?:градиент[ауы]?|прозрачност[ьи]|эффект[ауы]?|тень\b)/i,
    constructor_alignment: /(?:конструктор[ауы]?|шаблон[ауы]?|масштаб[ауы]?|смещени[ея]|совмещени[ея])/i
  });

  // vision/orders/order-page-discovery.mjs
  var TEST_HOSTS = Object.freeze(["psk.testgifts.local", "testgifts.local"]);
  function inertOrderDiscussionHtml(source) {
    if (typeof source !== "string" || source.length > 3e6) return null;
    const withoutScripts = source.replace(
      /<\s*(script|style)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi,
      ""
    );
    const withoutMedia = withoutScripts.replace(
      /<\s*(?:img|image|iframe|source|video|audio|track|embed|object|link)\b(?:[^>"']|"[^"]*"|'[^']*')*>/gi,
      '<span data-vision-media-candidate=""></span>'
    );
    if (/<\s*(?:img|image|iframe|source|video|audio|track|embed|object|link)\b/i.test(withoutMedia))
      return null;
    return withoutMedia;
  }

  // vision/orders/approval-range-scanner.mjs
  var RANGE_MIN = 32e5;
  var RANGE_MAX = 82e5;
  var MAX_BODY = 3e6;
  var digits = (s) => /^\d{5,12}$/.test(String(s || ""));
  var clear = (s) => String(s || "").replace(/\s+/g, " ").trim().toLocaleUpperCase("ru-RU");
  var exactText = (s) => clear(s) === "\u0422\u0417 \u0423\u0422\u0412\u0415\u0420\u0416\u0414\u0415\u041D\u041E";
  function rangeOrderUrl(number) {
    if (!Number.isSafeInteger(number) || number < RANGE_MIN || number > RANGE_MAX)
      throw Error("MANUAL_RANGE_ORDER_INVALID");
    return "http://testgifts.local/private/order/" + number;
  }
  function readTzApprovedStatus(doc, orderNumber) {
    if (!digits(orderNumber) || !doc?.querySelector) return { status: "MANUAL_ORDER_ID_INVALID" };
    const root = doc.querySelector("#j_cart_host[data-orderid]");
    if (!root) return { status: "MANUAL_ORDER_CARD_MISSING" };
    const shown = root.querySelector(".cart-header-number [data-clipboard-text]")?.getAttribute("data-clipboard-text")?.trim();
    if (shown !== String(orderNumber)) return { status: "MANUAL_ORDER_NUMBER_MISMATCH" };
    const fields = [...root.querySelectorAll(
      '.cart-log label input.j_toggle_status[data-id="59"][type="checkbox"]'
    )];
    if (fields.length !== 1) return { status: "MANUAL_TZ_STATUS_MISSING_OR_AMBIGUOUS" };
    const input = fields[0], label = input.closest("label");
    const texts = [...label?.querySelectorAll(".btn--toggle .on,.btn--toggle .off") || []].map((node) => node.textContent);
    if (texts.length !== 2 || !texts.every(exactText))
      return { status: "MANUAL_TZ_LABEL_UNVERIFIED" };
    return {
      status: input.checked === true ? "TZ_APPROVED" : "TZ_NOT_APPROVED",
      native_status_id: "59",
      status_text: "\u0422\u0417 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043D\u043E",
      status_checked: input.checked === true,
      native_order_id: root.getAttribute("data-orderid") || null
    };
  }
  function safeDoc(html, DOMParserClass) {
    if (typeof html !== "string" || html.length > MAX_BODY || typeof DOMParserClass !== "function")
      return null;
    const inert = inertOrderDiscussionHtml(html);
    if (!inert) return null;
    try {
      return new DOMParserClass().parseFromString(inert, "text/html");
    } catch {
      return null;
    }
  }
  async function boundedHtml(response) {
    const type = response.headers?.get?.("content-type") || "";
    if (!/html/i.test(type)) throw Error("MANUAL_NON_HTML_RESPONSE");
    const announced = response.headers?.get?.("content-length");
    if (announced && Number(announced) > MAX_BODY) throw Error("MANUAL_ORDER_BODY_TOO_LARGE");
    if (!response.body?.getReader) {
      const data = await response.text();
      if (data.length > MAX_BODY) throw Error("MANUAL_ORDER_BODY_TOO_LARGE");
      return data;
    }
    const reader = response.body.getReader(), parts = [];
    let bytes = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        bytes += value.byteLength;
        if (bytes > MAX_BODY) throw Error("MANUAL_ORDER_BODY_TOO_LARGE");
        parts.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const out = new Uint8Array(bytes);
    let offset = 0;
    for (const part of parts) {
      out.set(part, offset);
      offset += part.length;
    }
    return new TextDecoder("utf-8", { fatal: true }).decode(out);
  }
  async function probeTzForOrder(orderNumber, {
    fetcher = globalThis.__visionLocalTrustedTransport,
    DOMParserClass = globalThis.DOMParser,
    signal,
    explicitList = false
  } = {}) {
    const url = explicitList ? explicitListOrderUrl(orderNumber) : rangeOrderUrl(orderNumber);
    if (typeof fetcher !== "function") return { status: "MANUAL_MV3_TRANSPORT_REQUIRED" };
    let response;
    try {
      response = await fetcher(url, {
        method: "GET",
        signal,
        credentials: "include",
        redirect: "error",
        cache: "no-store"
      });
      if (response.status === 404 || response.status === 410)
        return { status: "ORDER_NOT_FOUND", http_status: response.status };
      if (response.status === 401 || response.status === 403)
        return { status: "MANUAL_ORDER_AUTH_REQUIRED", http_status: response.status };
      if (response.status === 429)
        return { status: "MANUAL_ORDER_RATE_LIMITED", http_status: 429 };
      if (response.status !== 200)
        return { status: "MANUAL_ORDER_HTTP_STATUS", http_status: response.status };
      const html = await boundedHtml(response);
      if (/<form[^>]+name=["']authform["']/i.test(html) || /Авторизация\s*-\s*Проект\s*111/i.test(html))
        return { status: "MANUAL_ORDER_AUTH_REQUIRED" };
      const doc = safeDoc(html, DOMParserClass);
      if (!doc) return { status: "MANUAL_ORDER_HTML_INVALID" };
      return readTzApprovedStatus(doc, String(orderNumber));
    } catch (error) {
      if (signal?.aborted) return { status: "MANUAL_PROBE_CANCELLED" };
      const token = String(error?.message || "");
      if (token === "EXTENSION_AUTH_REDIRECT" || token === "TEST_SESSION_AUTH_REQUIRED")
        return { status: "MANUAL_ORDER_AUTH_REQUIRED" };
      if (token === "MANUAL_ORDER_BODY_TOO_LARGE" || token === "MANUAL_NON_HTML_RESPONSE")
        return { status: token };
      return { status: "MANUAL_ORDER_FETCH_FAILED" };
    }
  }
  var RECOVERABLE_RANGE_FAILURES = /* @__PURE__ */ new Set([
    "MANUAL_ORDER_FETCH_FAILED",
    "MANUAL_ORDER_HTTP_STATUS",
    "MANUAL_ORDER_BODY_TOO_LARGE",
    "MANUAL_NON_HTML_RESPONSE",
    "MANUAL_ORDER_HTML_INVALID",
    "MANUAL_ORDER_CARD_MISSING",
    "MANUAL_ORDER_NUMBER_MISMATCH",
    "MANUAL_TZ_STATUS_MISSING_OR_AMBIGUOUS",
    "MANUAL_TZ_LABEL_UNVERIFIED",
    "MANUAL_ORDER_ID_INVALID",
    "MANUAL_BACKGROUND_ORDER_FAILED",
    "MANUAL_QUEUE_ORDER_TIMEOUT",
    "MANUAL_TAB_CLOSED",
    "MANUAL_ORDER_URL_MISMATCH",
    "MANUAL_AUTO_SCAN_FAILED",
    "MANUAL_TZ_RECHECK_FAILED",
    "MANUAL_TZ_CHANGED_BEFORE_SCAN",
    "MANUAL_NATIVE_APPROVAL_QUEUE_FAILED",
    "MANUAL_BATCH_EVIDENCE_ENCODING_FAILED",
    "MANUAL_BATCH_RELAY_FAILED",
    "MANUAL_BATCH_RELAY_REJECTED",
    "MANUAL_BATCH_PAYLOAD_TOO_LARGE",
    "MANUAL_APPROVAL_COLLECTION_INCOMPLETE"
  ]);
  function isRecoverableRangeFailure(status) {
    return RECOVERABLE_RANGE_FAILURES.has(status) || /^MANUAL_ORDER_TAB_[A-Z0-9_]{1,80}$/.test(status || "");
  }

  // vision/geometry/svg-viewport.mjs
  var mmMultipliers = Object.freeze({ mm: 1, cm: 10, in: 25.4, pt: 25.4 / 72 });

  // vision/ai/synthetic-feature-model.mjs
  var MODEL_INFO = Object.freeze({
    schema: "printcheck.vision.synthetic-feature-mlp.v1",
    source: "synthetic_width_classes_only",
    seed: 20261117,
    syntheticHoldoutN: 3e3,
    syntheticAccuracy: 0.99733,
    syntheticPrecision075: 0.99921,
    syntheticRecall075: 0.99219,
    realWorldAccuracyVerified: false,
    productionApproved: false
  });

  // vision/orders/row-scanner.mjs
  var LOCAL_ORDERS = Object.freeze({
    host: "psk.testgifts.local",
    route: "/devorders",
    // No row or file-count quota: read and inspect sequentially on user action.
    // The per-file size and network timeout guards remain mandatory.
    maxFileBytes: 16e6,
    timeoutMs: 15e3,
    fetchPaceMs: 30
  });

  // vision/orders/local-training-zip.mjs
  var te = new TextEncoder();

  // vision/orders/approval-attachments.mjs
  var te2 = new TextEncoder();
  var SHA256_K = new Uint32Array([
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ]);
  var rotr = (x, n) => x >>> n | x << 32 - n;
  function portableSha256Hex(bytes) {
    if (!(bytes instanceof Uint8Array)) throw new TypeError("SHA256_BYTES_REQUIRED");
    const size = bytes.length;
    const length = Math.ceil((size + 9) / 64) * 64;
    const data = new Uint8Array(length);
    data.set(bytes);
    data[size] = 128;
    const view = new DataView(data.buffer);
    view.setUint32(length - 8, Math.floor(size / 536870912));
    view.setUint32(length - 4, size * 8 >>> 0);
    const h = new Uint32Array([
      1779033703,
      3144134277,
      1013904242,
      2773480762,
      1359893119,
      2600822924,
      528734635,
      1541459225
    ]);
    const w = new Uint32Array(64);
    for (let offset = 0; offset < length; offset += 64) {
      for (let i = 0; i < 16; i++) w[i] = view.getUint32(offset + 4 * i);
      for (let i = 16; i < 64; i++) {
        const a2 = w[i - 15], b2 = w[i - 2];
        const s0 = rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3;
        const s1 = rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let [a, b, c, d, e, f, g, z] = h;
      for (let i = 0; i < 64; i++) {
        const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const choice = e & f ^ ~e & g;
        const t1 = z + s1 + choice + SHA256_K[i] + w[i] >>> 0;
        const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const majority = a & b ^ a & c ^ b & c;
        const t2 = s0 + majority >>> 0;
        z = g;
        g = f;
        f = e;
        e = d + t1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = t1 + t2 >>> 0;
      }
      for (const [i, value] of [a, b, c, d, e, f, g, z].entries()) h[i] = h[i] + value >>> 0;
    }
    return Array.from(h, (v) => v.toString(16).padStart(8, "0")).join("");
  }

  // vision/orders/approval-batch-archive.mjs
  var BATCH_MAX_BYTES = 18e7;
  var MAX_PART = 26e6;
  var MAX_PACKET = 48e3;
  var MAX_ENTRIES = 1e4;
  var te3 = new TextEncoder();
  var td = new TextDecoder("utf-8", { fatal: true });
  var numeric = (v) => typeof v === "string" && /^\d{5,12}$/.test(v);
  var fail = (c) => {
    throw Error(c);
  };
  var u16 = (v, n, d) => v.setUint16(n, d, true);
  var u32 = (v, n, d) => v.setUint32(n, d >>> 0, true);
  var json = (x) => te3.encode(JSON.stringify(x, null, 2) + "\n");
  function crc32(bytes) {
    let n = 4294967295;
    for (const b of bytes) {
      n ^= b;
      for (let i = 0; i < 8; i++) n = n >>> 1 ^ (n & 1 ? 3988292384 : 0);
    }
    return (n ^ 4294967295) >>> 0;
  }
  function safePath(name) {
    if (typeof name !== "string" || name.length > 420 || name.includes("..") || name.includes("\\") || name.startsWith("/") || name.includes("//") || /[\x00-\x1f\x7f]/.test(name)) return false;
    return name === "manifest.json" || name === "index/orders.json" || /^orders\/\d{5,12}\/(?:order|articles|approvals|review|files-index)\.json$/.test(name) || /^orders\/\d{5,12}\/source\/(?:evidence|backup)\.json$/.test(name) || /^orders\/\d{5,12}\/threads\/\d{1,20}\.json$/.test(name) || /^orders\/\d{5,12}\/assets\/[a-f0-9]{64}\.(?:pdf|psd|psb|png|jpe?g|webp|tiff?|gif|svg|eps|ai|cdr|zip)$/.test(name);
  }
  function buildVisionZip(entries) {
    if (!Array.isArray(entries) || !entries.length || entries.length > MAX_ENTRIES)
      fail("MANUAL_ZIP_ENTRY_COUNT");
    const chunks = [], central = [], names = /* @__PURE__ */ new Set();
    let position = 0, centralSize = 0;
    for (const { name, bytes } of entries) {
      if (!safePath(name) || names.has(name) || !(bytes instanceof Uint8Array) || bytes.length > MAX_PART) fail("MANUAL_ZIP_ENTRY_INVALID");
      const path = te3.encode(name);
      if (path.length > 65535) fail("MANUAL_ZIP_PATH_TOO_LONG");
      names.add(name);
      const size = bytes.length, c = crc32(bytes);
      const local = new Uint8Array(30 + path.length), dv = new DataView(local.buffer);
      u32(dv, 0, 67324752);
      u16(dv, 4, 20);
      u16(dv, 6, 2048);
      u16(dv, 8, 0);
      u16(dv, 10, 0);
      u16(dv, 12, 0);
      u32(dv, 14, c);
      u32(dv, 18, size);
      u32(dv, 22, size);
      u16(dv, 26, path.length);
      u16(dv, 28, 0);
      local.set(path, 30);
      const cd = new Uint8Array(46 + path.length), v = new DataView(cd.buffer);
      u32(v, 0, 33639248);
      u16(v, 4, 20);
      u16(v, 6, 20);
      u16(v, 8, 2048);
      u16(v, 10, 0);
      u16(v, 12, 0);
      u16(v, 14, 0);
      u32(v, 16, c);
      u32(v, 20, size);
      u32(v, 24, size);
      u16(v, 28, path.length);
      u16(v, 30, 0);
      u16(v, 32, 0);
      u16(v, 34, 0);
      u16(v, 36, 0);
      u32(v, 38, 0);
      u32(v, 42, position);
      cd.set(path, 46);
      chunks.push(local, bytes);
      central.push(cd);
      position += local.length + size;
      centralSize += cd.length;
      if (position + centralSize > BATCH_MAX_BYTES + 5e6) fail("MANUAL_ZIP_SIZE_LIMIT");
    }
    if (entries.length > 65535 || position + centralSize >= 4294967295) fail("MANUAL_ZIP32_LIMIT");
    const end = new Uint8Array(22), ev = new DataView(end.buffer);
    u32(ev, 0, 101010256);
    u16(ev, 4, 0);
    u16(ev, 6, 0);
    u16(ev, 8, entries.length);
    u16(ev, 10, entries.length);
    u32(ev, 12, centralSize);
    u32(ev, 16, position);
    u16(ev, 20, 0);
    return new Blob([...chunks, ...central, end], { type: "application/zip" });
  }
  function readStoredEntries(bytes) {
    if (!(bytes instanceof Uint8Array) || bytes.length < 22 || bytes.length > MAX_PART)
      fail("MANUAL_BAD_PART_LENGTH");
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let offset = 0;
    const result = /* @__PURE__ */ new Map();
    while (offset + 4 <= bytes.length && dv.getUint32(offset, true) === 67324752) {
      if (offset + 30 > bytes.length) fail("MANUAL_ZIP_HEADER_TRUNCATED");
      const flags = dv.getUint16(offset + 6, true), method = dv.getUint16(offset + 8, true);
      const expected = dv.getUint32(offset + 14, true), size = dv.getUint32(offset + 18, true);
      const compressed = dv.getUint32(offset + 22, true);
      const len = dv.getUint16(offset + 26, true), extra = dv.getUint16(offset + 28, true);
      if (flags !== 2048 || method !== 0 || size !== compressed || size > 16e6)
        fail("MANUAL_ZIP_UNSUPPORTED_CONTENT");
      const start = offset + 30 + len + extra, end = start + size;
      if (end > bytes.length || len === 0) fail("MANUAL_ZIP_TRUNCATED");
      const name = td.decode(bytes.subarray(offset + 30, offset + 30 + len));
      if (!/^(?:manifest\.json|attachments\/\d{4}\/\d{4}\.[a-z0-9]{2,5})$/.test(name) || result.has(name)) fail("MANUAL_ZIP_UNSAFE_INNER_NAME");
      const data = bytes.subarray(start, end);
      if (crc32(data) !== expected) fail("MANUAL_ZIP_CRC_MISMATCH");
      result.set(name, data);
      offset = end;
      if (result.size > 15) fail("MANUAL_ZIP_TOO_MANY_INNER_FILES");
    }
    if (!result.has("manifest.json") || offset + 22 > bytes.length)
      fail("MANUAL_ZIP_PART_UNREADABLE");
    if (dv.getUint32(offset, true) !== 33639248)
      fail("MANUAL_ZIP_CENTRAL_HEADER_MISSING");
    return result;
  }
  var fromB64 = (str) => {
    if (typeof str !== "string" || str.length > MAX_PACKET * 2 || !/^[A-Za-z0-9+/]*={0,2}$/.test(str)) fail("MANUAL_CHUNK_BASE64");
    const s = atob(str);
    if (s.length > MAX_PACKET) fail("MANUAL_CHUNK_TOO_LARGE");
    return Uint8Array.from(s, (c) => c.charCodeAt(0));
  };
  var ApprovalBatchSession = class {
    constructor() {
      this.transfers = /* @__PURE__ */ new Map();
      this.records = /* @__PURE__ */ new Map();
      this.bytesReceived = 0;
      this.partialFailures = [];
    }
    receive(message, expectedOrder) {
      try {
        const order = message?.order_number;
        if (!numeric(order) || order !== expectedOrder) fail("MANUAL_TRANSFER_ORDER_MISMATCH");
        const type = message?.kind;
        const stage = message?.stage;
        const part = message?.part;
        if (!(type === "evidence" && ["raw", "final"].includes(stage) && part === 0 || type === "attachment_zip" && stage === "binary" && Number.isInteger(part) && part >= 1 && part <= 64))
          fail("MANUAL_TRANSFER_KIND_INVALID");
        const seq = message?.sequence, total = message?.chunk_count;
        if (!Number.isInteger(seq) || !Number.isInteger(total) || total < 1 || total > 600 || seq < 0 || seq >= total) fail("MANUAL_TRANSFER_SEQUENCE");
        const key = [order, type, stage, part].join(":");
        let transfer = this.transfers.get(key);
        if (!transfer) {
          if (seq !== 0) fail("MANUAL_TRANSFER_FIRST_CHUNK_MISSING");
          transfer = { order, type, stage, part, total, next: 0, chunks: [], size: 0 };
          this.transfers.set(key, transfer);
        }
        if (transfer.total !== total || transfer.next !== seq) fail("MANUAL_TRANSFER_ORDERING");
        const bytes = fromB64(message.chunk);
        if (this.bytesReceived + bytes.length > BATCH_MAX_BYTES)
          fail("MANUAL_BATCH_MEMORY_LIMIT");
        transfer.chunks.push(bytes);
        transfer.size += bytes.length;
        this.bytesReceived += bytes.length;
        transfer.next++;
        if (transfer.next === transfer.total) {
          const data = new Uint8Array(transfer.size);
          let off = 0;
          for (const chunk of transfer.chunks) {
            data.set(chunk, off);
            off += chunk.length;
          }
          transfer.chunks = [];
          transfer.data = data;
          if (type === "evidence") {
            const decoded = JSON.parse(td.decode(data));
            if (decoded?.schema !== "printcheck.vision.private-approval-collection.v1" || decoded.order_number !== order || !Array.isArray(decoded.articles) || decoded.training_ready !== false || decoded.production_approved !== false)
              fail("MANUAL_BATCH_EVIDENCE_INVALID");
            transfer.report = decoded;
          } else {
            const parsed = readStoredEntries(data);
            const manifest = JSON.parse(td.decode(parsed.get("manifest.json")));
            if (manifest?.schema !== "printcheck.vision.private-approval-attachments.v1" || manifest.order_number !== order || manifest.package_part !== part || manifest.training_ready !== false || !Array.isArray(manifest.items))
              fail("MANUAL_BATCH_PART_MANIFEST_INVALID");
            transfer.manifest = manifest;
          }
        }
        return { status: "BATCH_CHUNK_ACCEPTED", complete: transfer.next === total };
      } catch (e) {
        return { status: String(e?.message || "MANUAL_BATCH_RECEIVE_ERROR").slice(0, 90) };
      }
    }
    get(order, type, stage, part) {
      const r = this.transfers.get([order, type, stage, part].join(":"));
      return r?.data ? r : null;
    }
    hasEvidence(order) {
      return !!this.get(order, "evidence", "final", 0);
    }
    /**
     * Persist only complete, independently validated transfer parts for an
     * approved order. An interrupted order is retried after a page reload.
     */
    exportOrder(order) {
      if (!numeric(order) || !this.hasEvidence(order))
        fail("MANUAL_RANGE_EVIDENCE_NOT_COMPLETE");
      const transfers = [...this.transfers.values()].filter((t) => t.order === order && t.data instanceof Uint8Array && t.next === t.total);
      if (!transfers.some((t) => t.type === "evidence" && t.stage === "final"))
        fail("MANUAL_RANGE_FINAL_EVIDENCE_MISSING");
      return transfers.map((t) => ({
        type: t.type,
        stage: t.stage,
        part: t.part,
        total: t.total,
        data: t.data,
        report: t.report || null,
        manifest: t.manifest || null
      }));
    }
    restoreOrder(order, parts) {
      if (!numeric(order) || !Array.isArray(parts) || parts.length > 68 || !parts.some((t) => t.type === "evidence" && t.stage === "final"))
        fail("MANUAL_RANGE_PERSISTED_EVIDENCE_INVALID");
      const restored = [];
      let size = 0;
      for (const t of parts) {
        if (!(t.type === "evidence" && ["raw", "final"].includes(t.stage) && t.part === 0 || t.type === "attachment_zip" && t.stage === "binary" && Number.isInteger(t.part) && t.part >= 1 && t.part <= 64) || !(t.data instanceof Uint8Array) || !Number.isInteger(t.total) || t.total < 1 || t.total > 600 || t.data.length > MAX_PART)
          fail("MANUAL_RANGE_PERSISTED_PART_INVALID");
        if (t.type === "evidence" && (t.report?.order_number !== order || t.report?.schema !== "printcheck.vision.private-approval-collection.v1"))
          fail("MANUAL_RANGE_PERSISTED_REPORT_INVALID");
        if (t.type === "attachment_zip" && (t.manifest?.order_number !== order || t.manifest?.schema !== "printcheck.vision.private-approval-attachments.v1"))
          fail("MANUAL_RANGE_PERSISTED_MANIFEST_INVALID");
        const key = [order, t.type, t.stage, t.part].join(":");
        if (this.transfers.has(key) || restored.some((x) => x.key === key))
          fail("MANUAL_RANGE_PERSISTED_DUPLICATE");
        size += t.data.length;
        restored.push({ key, t });
      }
      if (this.bytesReceived + size > BATCH_MAX_BYTES)
        fail("MANUAL_RANGE_PERSISTED_MEMORY_LIMIT");
      for (const { key, t } of restored) this.transfers.set(key, {
        order,
        type: t.type,
        stage: t.stage,
        part: t.part,
        total: t.total,
        next: t.total,
        size: t.data.length,
        chunks: [],
        data: t.data,
        report: t.report || void 0,
        manifest: t.manifest || void 0
      });
      this.bytesReceived += size;
    }
    discardOrder(order) {
      for (const [key, t] of this.transfers) {
        if (t.order !== order) continue;
        this.bytesReceived = Math.max(0, this.bytesReceived - (t.size || 0));
        this.transfers.delete(key);
      }
    }
    receivedOrderIds() {
      return [...new Set([...this.transfers.values()].map((x) => x.order))].sort();
    }
    finalize(orderedResults = []) {
      const entries = [], index = [];
      let verified = 0, missing = 0, unverifiedOrders = 0;
      for (const row of orderedResults) {
        const order = row.order_number;
        if (!numeric(order)) fail("MANUAL_BATCH_ORDER_INVALID");
        const evidence = this.get(order, "evidence", "final", 0) || this.get(order, "evidence", "raw", 0);
        if (!evidence) {
          unverifiedOrders++;
          index.push({
            order_number: order,
            collection_status: row.status,
            evidence_status: "MISSING"
          });
          continue;
        }
        const source = evidence.report, base = "orders/" + order + "/";
        const orderFacts = source.order_facts || {};
        entries.push({ name: base + "order.json", bytes: json(orderFacts.order || {}) });
        entries.push({ name: base + "articles.json", bytes: json(orderFacts.articles || []) });
        entries.push({ name: base + "source/evidence.json", bytes: evidence.data });
        const raw = this.get(order, "evidence", "raw", 0);
        if (raw && evidence.stage === "final")
          entries.push({ name: base + "source/backup.json", bytes: raw.data });
        const approvals = [];
        const fileIndex = [], assetPaths = /* @__PURE__ */ new Set();
        for (const article of source.articles) {
          const item = article.item_id;
          const itemName = typeof item === "string" && /^\d{1,20}$/.test(item) ? item : "unknown";
          approvals.push({
            item_id: item,
            status: article.status,
            declared_message_badge: article.declared_message_badge,
            observed_human_comments: article.observed_human_comments,
            current_problems: article.current_problems || [],
            additional_problem_description: article.additional_problem_description || "",
            source_pdf_revision_confirmed: false,
            expert_roi_confirmed: false
          });
          if (Array.isArray(article.history)) {
            if (itemName === "unknown") fail("MANUAL_ARTICLE_ID_UNKNOWN");
            entries.push({ name: base + "threads/" + itemName + ".json", bytes: json({
              order_number: order,
              item_id: item,
              history: article.history,
              current_problems: article.current_problems || [],
              training_ready: false
            }) });
          }
        }
        entries.push({ name: base + "approvals.json", bytes: json(approvals) });
        const actualPartItems = /* @__PURE__ */ new Map();
        for (let part = 1; part <= 64; part++) {
          const p = this.get(order, "attachment_zip", "binary", part);
          if (!p) continue;
          const files = readStoredEntries(p.data);
          for (const info of p.manifest.items) {
            const bytes = files.get(info.entry);
            if (!bytes || bytes.length !== info.bytes || portableSha256Hex(bytes) !== info.sha256)
              fail("MANUAL_BATCH_FILE_SHA_MISMATCH");
            const ext = String(info.original_filename || "").split(".").at(-1).toLowerCase();
            if (!/^(?:pdf|psd|psb|png|jpe?g|webp|tiff?|gif|svg|eps|ai|cdr|zip)$/.test(ext))
              fail("MANUAL_BATCH_FILE_EXTENSION");
            const sha2 = info.sha256;
            const path = base + "assets/" + sha2 + "." + ext;
            if (!assetPaths.has(path)) {
              entries.push({ name: path, bytes });
              assetPaths.add(path);
            }
            const key = part + ":" + info.entry;
            if (actualPartItems.has(key)) fail("MANUAL_BATCH_DUPLICATE_FILE");
            actualPartItems.set(key, { ...info, asset_path: path });
          }
        }
        for (const article of source.articles) {
          for (const m of article.history || []) {
            for (const a of m.attachments || []) {
              const key = a.private_zip_part + ":" + a.private_zip_entry;
              const found = actualPartItems.get(key);
              if (a.local_get_status === "LOCAL_ATTACHMENT_BYTES_ONLY") {
                if (!found || found.order_item_id !== article.item_id || found.comment_sequence !== m.sequence || found.sha256 !== a.sha256 || found.original_filename !== a.filename)
                  fail("MANUAL_BATCH_ATTACHMENT_LINK_MISMATCH");
                fileIndex.push({
                  item_id: article.item_id,
                  comment_sequence: m.sequence,
                  native_comment_id: m.native_comment_id || null,
                  original_filename: a.filename,
                  source: a.source || "native_attachment",
                  attachment_id: a.attachment_id || null,
                  sha256: a.sha256,
                  asset_path: found.asset_path
                });
                verified++;
              } else {
                missing++;
                fileIndex.push({
                  item_id: article.item_id,
                  comment_sequence: m.sequence,
                  original_filename: a.filename,
                  download_status: a.local_get_status || "NOT_ATTEMPTED",
                  asset_path: null,
                  sha256: null
                });
              }
            }
          }
        }
        entries.push({ name: base + "files-index.json", bytes: json(fileIndex) });
        entries.push({ name: base + "review.json", bytes: json({
          order_number: order,
          source_pdf_revision_confirmed: false,
          expert_roi_confirmed: false,
          training_ready: false,
          production_approved: false,
          pending_checks: ["SOURCE_ARTWORK_REVISION", "PRINT_METHOD", "EXPERT_ROI", "EXPERT_LABELS"]
        }) });
        index.push({
          order_number: order,
          collection_status: row.status,
          evidence_status: evidence.stage === "final" ? "FINAL" : "BACKUP_ONLY",
          articles: source.articles.length,
          files_verified: fileIndex.filter((x) => x.asset_path).length,
          files_unavailable: fileIndex.filter((x) => !x.asset_path).length
        });
      }
      const counts = {
        orders: index.length,
        with_evidence: index.filter((x) => x.evidence_status !== "MISSING").length,
        unverified_orders: unverifiedOrders,
        verified_files: verified,
        missing_files: missing
      };
      entries.unshift({ name: "index/orders.json", bytes: json(index) });
      entries.unshift({ name: "manifest.json", bytes: json({
        schema: "printcheck.vision.local-batch-corpus.v1",
        created_at: (/* @__PURE__ */ new Date()).toISOString(),
        scope: "LOCAL_TEST_ONLY",
        counts,
        order_results: index,
        training_ready: false,
        production_approved: false,
        remote_upload: false,
        expert_labels_verified: false,
        source_pdf_revision_confirmed: false,
        notes: "All named discussions and order facts are source evidence, not verified training labels."
      }) });
      return {
        status: "BATCH_ARCHIVE_READY",
        blob: buildVisionZip(entries),
        counts,
        entry_count: entries.length
      };
    }
  };

  // vision/orders/approval-file-batch-policy.mjs
  var APPROVED_ORDERS_PER_ZIP = 100;
  var SOFT_BATCH_PAYLOAD_LIMIT = 12e7;
  function archivePayloadBytes(rows) {
    if (!Array.isArray(rows)) throw Error("VISION_BATCH_ROWS_INVALID");
    let total = 0;
    for (const row of rows) {
      if (!Array.isArray(row?.transfers))
        throw Error("VISION_BATCH_ROW_TRANSFERS_INVALID");
      for (const transfer of row.transfers)
        total += transfer?.data?.byteLength || 0;
    }
    return total;
  }
  function selectArchiveRows(rows) {
    if (!Array.isArray(rows)) throw Error("VISION_BATCH_ROWS_INVALID");
    return rows.slice(0, APPROVED_ORDERS_PER_ZIP);
  }
  function archiveBatchDue(rows) {
    return rows.length >= APPROVED_ORDERS_PER_ZIP || rows.length > 0 && archivePayloadBytes(rows) >= SOFT_BATCH_PAYLOAD_LIMIT;
  }

  // vision/orders/extension-zip-transfer.mjs
  async function startExtensionZipDownload(blob, filename) {
    if (!(blob instanceof Blob) || blob.size < 100 || blob.size > 2e8 || !/^vision-ai-(?:range-\d{7}-\d{7}-part|list-part)-\d{5}-\d{7}-\d{7}\.zip$/.test(filename))
      throw Error("VISION_ZIP_TRANSFER_ARGS_INVALID");
    if (!globalThis.chrome?.runtime?.sendMessage)
      throw Error("VISION_ZIP_EXTENSION_TRANSPORT_REQUIRED");
    const random = new Uint8Array(16);
    crypto.getRandomValues(random);
    const job = Array.from(random, (b) => b.toString(16).padStart(2, "0")).join("");
    const command = (op, extra = {}) => chrome.runtime.sendMessage({
      op: "vision-zip-secure-message-v1",
      action: op,
      job,
      ...extra
    });
    const begin = await command("begin", { filename, size: blob.size });
    if (begin?.status !== "ZIP_READY_FOR_CHUNK")
      throw Error(begin?.status || "VISION_ZIP_BEGIN_FAILED");
    let finished = false;
    try {
      let sequence = 0;
      for (let offset = 0; offset < blob.size; offset += 48e3) {
        const part = new Uint8Array(await blob.slice(offset, offset + 48e3).arrayBuffer());
        let binary = "";
        for (let i = 0; i < part.length; i += 8192)
          binary += String.fromCharCode(...part.subarray(i, i + 8192));
        const result2 = await command("chunk", { sequence, base64: btoa(binary) });
        if (result2?.status !== "ZIP_CHUNK_ACCEPTED")
          throw Error(result2?.status || "VISION_ZIP_CHUNK_FAILED");
        sequence++;
      }
      const result = await command("finish", { chunks: sequence });
      if (result?.status !== "ZIP_DOWNLOAD_STARTED" || !Number.isSafeInteger(result.download_id) || result.download_id < 0)
        throw Error(result?.status || "VISION_ZIP_FINISH_FAILED");
      finished = true;
      return result.download_id;
    } finally {
      if (!finished) void command("cancel").catch(() => {
      });
    }
  }

  // vision/orders/approval-network-control.mjs
  var NETWORK_RETRY_LIMIT = 3;
  var NETWORK_CIRCUIT_LIMIT = 6;
  var freshNetworkHealth = () => ({
    attempts: 0,
    retries: 0,
    transient_errors: 0,
    consecutive_errors: 0,
    auth_errors: 0,
    rate_limits: 0,
    last_error: null,
    last_http_status: null,
    last_error_at: null,
    last_success_at: null,
    last_request_at: null,
    state: "idle",
    last_duration_ms: null
  });
  function normalizeNetworkHealth(value) {
    const base = freshNetworkHealth();
    if (!value || typeof value !== "object") return base;
    for (const key of [
      "attempts",
      "retries",
      "transient_errors",
      "consecutive_errors",
      "auth_errors",
      "rate_limits"
    ]) {
      const n = value[key];
      if (Number.isSafeInteger(n) && n >= 0) base[key] = n;
    }
    for (const key of [
      "last_error",
      "last_error_at",
      "last_success_at",
      "last_request_at",
      "state"
    ]) {
      if (typeof value[key] === "string" && value[key].length <= 100)
        base[key] = value[key];
    }
    if (Number.isInteger(value.last_http_status) && value.last_http_status >= 100 && value.last_http_status <= 599) base.last_http_status = value.last_http_status;
    if (Number.isSafeInteger(value.last_duration_ms) && value.last_duration_ms >= 0)
      base.last_duration_ms = value.last_duration_ms;
    return base;
  }
  function networkFailureType(result) {
    const status = String(result?.status || "");
    if (status === "MANUAL_ORDER_AUTH_REQUIRED") return "auth";
    if (status === "MANUAL_ORDER_RATE_LIMITED") return "rate_limit";
    if ([
      "MANUAL_ORDER_FETCH_FAILED",
      "EXTENSION_FETCH_TIMEOUT",
      "MANUAL_NON_HTML_RESPONSE"
    ].includes(status)) return "transient";
    if (status === "MANUAL_ORDER_HTTP_STATUS") {
      if (result.http_status === 401 || result.http_status === 403) return "auth";
      if (result.http_status === 429) return "rate_limit";
      if (result.http_status === 408 || result.http_status >= 500 && result.http_status <= 599) return "transient";
    }
    if (["TZ_APPROVED", "TZ_NOT_APPROVED", "ORDER_NOT_FOUND"].includes(status))
      return "ok";
    return "other";
  }
  async function controlledOrderProbe(order, probe, {
    health = freshNetworkHealth(),
    sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms)),
    now = () => (/* @__PURE__ */ new Date()).toISOString(),
    maxRetries = NETWORK_RETRY_LIMIT
  } = {}) {
    if (typeof probe !== "function" || !Number.isInteger(maxRetries) || maxRetries < 0 || maxRetries > 3) throw Error("VISION_NETWORK_CONFIG_INVALID");
    const stats = normalizeNetworkHealth(health);
    const started = Date.now();
    let response = null, kind = "other", used = 0;
    stats.last_request_at = now();
    stats.state = "requesting";
    for (let n = 0; n <= maxRetries; n++) {
      stats.attempts++;
      try {
        response = await probe(order);
      } catch {
        response = { status: "MANUAL_ORDER_FETCH_FAILED" };
      }
      kind = networkFailureType(response);
      if (kind !== "transient" || n === maxRetries) break;
      stats.retries++;
      used++;
      await sleep(Math.min(2e3, 400 * (n + 1)));
    }
    stats.last_duration_ms = Math.max(0, Date.now() - started);
    if (kind === "ok") {
      stats.consecutive_errors = 0;
      stats.last_success_at = now();
      stats.last_error = null;
      stats.last_http_status = null;
      stats.state = "online";
    } else {
      stats.last_error = String(response?.status || "MANUAL_ORDER_PROBE_UNKNOWN").slice(0, 80);
      stats.last_http_status = Number.isInteger(response?.http_status) ? response.http_status : null;
      stats.last_error_at = now();
      if (kind === "transient") {
        stats.transient_errors++;
        stats.consecutive_errors++;
        stats.state = stats.consecutive_errors >= NETWORK_CIRCUIT_LIMIT ? "circuit_open" : "degraded";
      } else if (kind === "auth") {
        stats.auth_errors++;
        stats.state = "auth_required";
      } else if (kind === "rate_limit") {
        stats.rate_limits++;
        stats.state = "rate_limited";
      } else stats.state = "degraded";
    }
    const halt = kind === "auth" || kind === "rate_limit" || kind === "transient" && stats.consecutive_errors >= NETWORK_CIRCUIT_LIMIT;
    return {
      result: response,
      health: stats,
      retries: used,
      kind,
      halt,
      reason: halt ? kind === "transient" ? "VISION_NETWORK_CIRCUIT_OPEN" : kind === "auth" ? "VISION_NETWORK_AUTH_REQUIRED" : "VISION_NETWORK_RATE_LIMITED" : null
    };
  }

  // vision/orders/approval-file-persistence.mjs
  var LIST_DB_NAME = "vision-ai-approved-file-list-v1";
  var LIST_STATUS_SCHEMA = "printcheck.vision.order-file-list.v1";
  var STORE_QUEUE = "queue";
  var STORE_STATE = "state";
  var STORE_PENDING = "pending";
  var STORE_SUCCESS = "success";
  var STORE_FAILURES = "failures";
  var STORES = [STORE_QUEUE, STORE_STATE, STORE_PENDING, STORE_SUCCESS, STORE_FAILURES];
  var KEY = "active";
  var checkState = (s) => {
    if (s?.schema !== LIST_STATUS_SCHEMA || !Number.isSafeInteger(s.index) || s.index < 0 || !Number.isSafeInteger(s.total) || s.total < 1 || !Number.isSafeInteger(s.archive_count) || s.archive_count < 0 || !Number.isSafeInteger(s.found_committed) || s.found_committed < 0 || !Number.isSafeInteger(s.delay_ms) || s.delay_ms < 100 || s.delay_ms > 6e4 || !["running", "paused", "stopped", "downloading"].includes(s.mode))
      throw Error("MANUAL_ORDER_LIST_STATE_INVALID");
  };
  async function openDb(factory = globalThis.indexedDB) {
    if (!factory?.open) throw Error("MANUAL_ORDER_LIST_INDEXEDDB_UNAVAILABLE");
    return new Promise((resolve, reject) => {
      const req = factory.open(LIST_DB_NAME, 1);
      req.onupgradeneeded = () => {
        const db = req.result;
        for (const store of STORES)
          if (!db.objectStoreNames.contains(store))
            db.createObjectStore(store, { keyPath: "id" });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(Error("MANUAL_ORDER_LIST_DB_OPEN_FAILED"));
      req.onblocked = () => reject(Error("MANUAL_ORDER_LIST_DB_BLOCKED"));
    });
  }
  async function transact(stores, mode, build, factory) {
    const db = await openDb(factory);
    try {
      return await new Promise((resolve, reject) => {
        let tx, extract;
        try {
          tx = db.transaction(stores, mode);
          extract = build(tx);
        } catch (error) {
          reject(error);
          return;
        }
        tx.oncomplete = () => {
          try {
            resolve(typeof extract === "function" ? extract() : void 0);
          } catch (error) {
            reject(error);
          }
        };
        tx.onabort = () => reject(Error("MANUAL_ORDER_LIST_DB_TRANSACTION_ABORTED"));
        tx.onerror = () => reject(Error("MANUAL_ORDER_LIST_DB_TRANSACTION_FAILED"));
      });
    } finally {
      db.close();
    }
  }
  async function loadOrderFileState(factory) {
    return transact([STORE_QUEUE, STORE_STATE, STORE_PENDING], "readonly", (tx) => {
      const queue = tx.objectStore(STORE_QUEUE).get(KEY);
      const state = tx.objectStore(STORE_STATE).get(KEY);
      const pending = tx.objectStore(STORE_PENDING).getAll();
      return () => {
        if (!queue.result && !state.result) return null;
        if (!queue.result || !state.result)
          throw Error("MANUAL_ORDER_LIST_INCOMPLETE_STATE");
        checkState(state.result);
        if (!(queue.result.numbers instanceof Uint32Array) || queue.result.numbers.length !== state.result.total || state.result.index > state.result.total)
          throw Error("MANUAL_ORDER_LIST_QUEUE_CORRUPTED");
        const orders = pending.result || [];
        if (orders.length > 200 || orders.some((x) => !/^[0-9]{7}$/.test(x.id) || !Array.isArray(x.transfers)))
          throw Error("MANUAL_ORDER_LIST_PENDING_CORRUPTED");
        return { queue: queue.result.numbers, state: state.result, pending: orders };
      };
    }, factory);
  }
  async function importOrderFileQueue(numbers, filename, delayMs = 1200, factory) {
    if (!Array.isArray(numbers) || !numbers.length || numbers.length > 1e6 || numbers.some((n) => !Number.isSafeInteger(n) || n < 1e6 || n > 9999999) || new Set(numbers).size !== numbers.length)
      throw Error("MANUAL_ORDER_LIST_IMPORT_INVALID");
    if (!Number.isSafeInteger(delayMs) || delayMs < 100 || delayMs > 6e4)
      throw Error("MANUAL_ORDER_LIST_DELAY_INVALID");
    const state = {
      id: KEY,
      schema: LIST_STATUS_SCHEMA,
      mode: "paused",
      filename: String(filename || "orders.txt").slice(0, 120),
      total: numbers.length,
      index: 0,
      archive_count: 0,
      found_committed: 0,
      failed_count: 0,
      delay_ms: delayMs,
      download: null,
      imported_at: (/* @__PURE__ */ new Date()).toISOString(),
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    await transact(STORES, "readwrite", (tx) => {
      for (const store of STORES) tx.objectStore(store).clear();
      tx.objectStore(STORE_QUEUE).put({ id: KEY, numbers: Uint32Array.from(numbers) });
      tx.objectStore(STORE_STATE).put(state);
    }, factory);
    return state;
  }
  async function saveOrderFileProgress(state, order = null, failure = null, factory) {
    checkState(state);
    if (order && (!/^[0-9]{7}$/.test(order.id) || !Array.isArray(order.transfers))) throw Error("MANUAL_ORDER_LIST_RECORD_INVALID");
    if (failure && !/^[0-9]{7}$/.test(failure.id))
      throw Error("MANUAL_ORDER_LIST_FAILURE_INVALID");
    return transact([STORE_STATE, STORE_PENDING, STORE_FAILURES], "readwrite", (tx) => {
      tx.objectStore(STORE_STATE).put({ ...state, updated_at: (/* @__PURE__ */ new Date()).toISOString() });
      if (order) tx.objectStore(STORE_PENDING).put(order);
      if (failure) tx.objectStore(STORE_FAILURES).put(failure);
    }, factory);
  }
  async function saveOrderFileStatus(state, factory) {
    checkState(state);
    return transact([STORE_STATE], "readwrite", (tx) => tx.objectStore(STORE_STATE).put({ ...state, updated_at: (/* @__PURE__ */ new Date()).toISOString() }), factory);
  }
  async function commitOrderFileArchive(state, records, factory) {
    checkState(state);
    if (!Array.isArray(records) || records.length < 1 || records.length > 100 || records.some((x) => !/^[0-9]{7}$/.test(x.id))) throw Error("MANUAL_ORDER_LIST_COMMIT_INVALID");
    if (state.download !== null) throw Error("MANUAL_ORDER_LIST_DOWNLOAD_NOT_CLEARED");
    return transact([STORE_STATE, STORE_PENDING, STORE_SUCCESS], "readwrite", (tx) => {
      tx.objectStore(STORE_STATE).put({ ...state, updated_at: (/* @__PURE__ */ new Date()).toISOString() });
      for (const row of records) {
        tx.objectStore(STORE_PENDING).delete(row.id);
        tx.objectStore(STORE_SUCCESS).put({
          id: row.id,
          order_number: row.id,
          collection_status: "TZ_APPROVED",
          collected_at: row.collected_at,
          files: row.files,
          eligible_articles: row.eligible_articles,
          verified_articles: row.verified_articles
        });
      }
    }, factory);
  }
  async function exportOrderFileRegistry(factory) {
    return transact([STORE_STATE, STORE_SUCCESS, STORE_FAILURES], "readonly", (tx) => {
      const status = tx.objectStore(STORE_STATE).get(KEY);
      const found = tx.objectStore(STORE_SUCCESS).getAll();
      const failed = tx.objectStore(STORE_FAILURES).getAll();
      return () => ({
        state: status.result,
        found_archived: found.result || [],
        failed_orders: failed.result || []
      });
    }, factory);
  }
  async function clearOrderFileQueue(factory) {
    return transact(STORES, "readwrite", (tx) => {
      for (const store of STORES) tx.objectStore(store).clear();
    }, factory);
  }

  // vision/orders/approval-file-controller.mjs
  var el = (tag, value) => {
    const n = document.createElement(tag);
    if (value !== void 0) n.textContent = value;
    return n;
  };
  var button = (label, fn) => {
    const b = el("button", label);
    b.type = "button";
    b.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      void fn();
    });
    return b;
  };
  var wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  var pad = (n) => String(n).padStart(5, "0");
  var acceptedRate = (n) => Number.isSafeInteger(n) && n >= 100 && n <= 6e4;
  function makeApprovalFileListController({
    getBusy = () => false,
    setBusy = () => {
    },
    scanOrder = async () => null,
    isClosed = () => false,
    refreshControls = () => {
    }
  } = {}) {
    const root = el("div");
    root.className = "vlo-file-list";
    root.style.cssText = "width:100%;border:1px solid #69898b;border-radius:8px;padding:10px;margin:10px 0;";
    root.append(el("strong", "\u0421\u043F\u0438\u0441\u043E\u043A \u0437\u0430\u043A\u0430\u0437\u043E\u0432 \u0438\u0437 \u0444\u0430\u0439\u043B\u0430 TXT"));
    root.append(el("p", "\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 \u0444\u0430\u0439\u043B \u0441 \u0441\u0435\u043C\u0438\u0437\u043D\u0430\u0447\u043D\u044B\u043C\u0438 \u043D\u043E\u043C\u0435\u0440\u0430\u043C\u0438: \u043E\u0434\u0438\u043D \u043D\u043E\u043C\u0435\u0440 \u0432 \u0441\u0442\u0440\u043E\u043A\u0435. \u041F\u043E\u0432\u0442\u043E\u0440\u044B \u0443\u0434\u0430\u043B\u044F\u044E\u0442\u0441\u044F. \u041F\u0440\u043E\u0432\u0435\u0440\u044F\u044E\u0442\u0441\u044F \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u043E\u043C\u0435\u0440\u0430 \u0438\u0437 \u0444\u0430\u0439\u043B\u0430, \u043D\u0435\u0437\u0430\u0432\u0438\u0441\u0438\u043C\u043E \u043E\u0442 \u0433\u0440\u0430\u043D\u0438\u0446 \u0440\u0435\u0436\u0438\u043C\u0430 \u0434\u0438\u0430\u043F\u0430\u0437\u043E\u043D\u0430. ZIP \u043F\u043E 100 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u0437\u0430\u043A\u0430\u0437\u043E\u0432; \u043F\u0440\u0438 \u0437\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u0438\u0438 \u0441\u043F\u0438\u0441\u043A\u0430 \u0438\u043B\u0438 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0435 \u2014 ZIP \u043D\u0435\u043F\u043E\u043B\u043D\u043E\u0439 \u043F\u0430\u0440\u0442\u0438\u0438. \u041F\u0440\u0438 \u043F\u0440\u0435\u0432\u044B\u0448\u0435\u043D\u0438\u0438 \u0431\u0435\u0437\u043E\u043F\u0430\u0441\u043D\u043E\u0433\u043E \u0440\u0430\u0437\u043C\u0435\u0440\u0430 ZIP \u043F\u0430\u0440\u0442\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u044F\u0435\u0442\u0441\u044F \u0440\u0430\u043D\u044C\u0448\u0435."));
    const fileLabel = el("label", "\u0412\u044B\u0431\u0440\u0430\u0442\u044C TXT \u0441\u043E \u0441\u043F\u0438\u0441\u043A\u043E\u043C ");
    const fileInput = el("input");
    fileInput.type = "file";
    fileInput.accept = ".txt,text/plain";
    fileInput.title = "\u041E\u0434\u0438\u043D \u0441\u0435\u043C\u0438\u0437\u043D\u0430\u0447\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440 \u0437\u0430\u043A\u0430\u0437\u0430 \u0432 \u043A\u0430\u0436\u0434\u043E\u0439 \u0441\u0442\u0440\u043E\u043A\u0435, \u0434\u043E 20 \u041C\u0411";
    fileInput.style.cssText = "max-width:100%;margin:4px 0;";
    fileLabel.append(fileInput);
    root.append(fileLabel);
    const rateLabel = el("label", "\u0417\u0430\u0434\u0435\u0440\u0436\u043A\u0430 \u043C\u0435\u0436\u0434\u0443 \u043D\u043E\u043C\u0435\u0440\u0430\u043C\u0438, \u043C\u0441 ");
    const rateInput = el("input");
    rateInput.type = "number";
    rateInput.value = "1200";
    rateInput.min = "100";
    rateInput.max = "60000";
    rateInput.step = "100";
    rateInput.title = "100\u201360000 \u043C\u0441, \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u0441\u0440\u0430\u0437\u0443";
    rateInput.style.cssText = "max-width:110px;color:#203436;background:#f2f8f3;padding:5px;border-radius:4px;";
    rateLabel.append(rateInput);
    root.append(rateLabel);
    const controls = el("div");
    controls.className = "vlo-actions";
    const startBtn = button("\u0421\u0442\u0430\u0440\u0442 / \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u043F\u043E \u0441\u043F\u0438\u0441\u043A\u0443", () => start());
    const pauseBtn = button("\u041F\u0430\u0443\u0437\u0430 \u0441\u043F\u0438\u0441\u043A\u0430", () => {
      paused = true;
      void setMode("paused");
      show("\u041F\u0430\u0443\u0437\u0430 \u043F\u043E\u0441\u043B\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u0437\u0430\u043A\u0430\u0437\u0430");
    });
    const stopBtn = button("\u0421\u0442\u043E\u043F \u0438 \u0430\u0440\u0445\u0438\u0432 \u0441\u043F\u0438\u0441\u043A\u0430", () => {
      stopped = true;
      stopWithoutZip = false;
      void setMode("stopped");
      show("\u0421\u043E\u0445\u0440\u0430\u043D\u044E \u043D\u0435\u043F\u043E\u043B\u043D\u0443\u044E ZIP-\u043F\u0430\u0440\u0442\u0438\u044E \u043F\u043E\u0441\u043B\u0435 \u0442\u0435\u043A\u0443\u0449\u0435\u0433\u043E \u0437\u0430\u043A\u0430\u0437\u0430");
      if (!running) void manualSave();
    });
    const saveBtn = button("\u0421\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043D\u0435\u043F\u043E\u043B\u043D\u0443\u044E ZIP \u0441\u043F\u0438\u0441\u043A\u0430", () => manualSave());
    const exportBtn = button("\u0420\u0435\u0435\u0441\u0442\u0440 \u0441\u043F\u0438\u0441\u043A\u0430 JSON", () => exportRegistry());
    const resetBtn = button("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0438 \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441", () => reset());
    controls.append(startBtn, pauseBtn, stopBtn, saveBtn, exportBtn, resetBtn);
    root.append(controls);
    const progress = el("p", "\u0421\u043F\u0438\u0441\u043E\u043A \u0437\u0430\u043A\u0430\u0437\u043E\u0432 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D.");
    progress.style.whiteSpace = "pre-line";
    root.append(progress);
    pauseBtn.disabled = stopBtn.disabled = saveBtn.disabled = true;
    let state = null, queue = null, pending = [], batch = new ApprovalBatchSession();
    let running = false, paused = false, stopped = false, activeOrder2 = null;
    let currentDelay = 1200, lastError = null, checkedSession = 0;
    let restoreBlocked = false, writeChain = Promise.resolve();
    let networkHealth = freshNetworkHealth(), lastActivityAt = null;
    let stopWithoutZip = false, stage = "idle";
    let init = Promise.resolve(false);
    const write = (fn) => {
      writeChain = writeChain.catch(() => {
      }).then(fn);
      return writeChain;
    };
    const currentMode = () => stopped ? "stopped" : paused ? "paused" : running ? "running" : "paused";
    function show(message = "") {
      const next = state && state.index < state.total ? String(queue[state.index]) : "\u2014";
      progress.textContent = (state ? "\u0424\u0430\u0439\u043B: " + state.filename + " \xB7 \u0432\u0441\u0435\u0433\u043E: " + state.total + " \xB7 \u043E\u0431\u0440\u0430\u0431\u043E\u0442\u0430\u043D\u043E: " + state.index + " \xB7 \u0437\u0430\u0434\u0435\u0440\u0436\u043A\u0430: " + currentDelay + " \u043C\u0441" : "\u0424\u0430\u0439\u043B \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D") + "\n\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0437\u0430\u043A\u0430\u0437: " + next + " \xB7 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043E \u043F\u043E\u0441\u043B\u0435 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F: " + checkedSession + " \xB7 ZIP: " + (state?.archive_count || 0) + " \xB7 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0438 \u0430\u0440\u0445\u0438\u0432\u0438\u0440\u043E\u0432\u0430\u043D\u043E: " + (state?.found_committed || 0) + " \xB7 \u0432 \u0442\u0435\u043A\u0443\u0449\u0435\u0439 \u043F\u0430\u0440\u0442\u0438\u0438: " + activeRows().length + "/" + APPROVED_ORDERS_PER_ZIP + " \xB7 ZIP \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u0435\u0442\u0441\u044F: " + (state?.download ? 1 : 0) + " \xB7 \u043E\u0448\u0438\u0431\u043E\u043A \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F: " + (state?.failed_count || 0) + " \xB7 \u0441\u0435\u0442\u044C: " + networkHealth.state + " \xB7 \u043F\u043E\u0432\u0442\u043E\u0440\u043E\u0432 GET: " + networkHealth.retries + " \xB7 \u0441\u0435\u0442\u0435\u0432\u044B\u0445 \u043E\u0448\u0438\u0431\u043E\u043A: " + networkHealth.transient_errors + " \xB7 \u0444\u0430\u0437\u0430: " + stage + (lastError ? "\n\u041E\u0448\u0438\u0431\u043A\u0430: " + lastError : "") + (message ? "\n" + message : "");
    }
    const activeRows = () => pending.filter((row) => !state?.download?.order_ids?.includes(row.id));
    const activeBytes = () => archivePayloadBytes(activeRows());
    const captureMode = (mode) => {
      if (!state) return null;
      state = { ...state, mode, delay_ms: currentDelay };
      return { ...state };
    };
    async function setMode(mode) {
      if (!state) return;
      const snapshot = captureMode(mode);
      try {
        await write(() => saveOrderFileStatus(snapshot));
      } catch (error) {
        lastError = String(error?.message || "MANUAL_LIST_MODE_FAILED");
        show();
      }
    }
    function validateDelay() {
      const n = Number(rateInput.value);
      return acceptedRate(n) ? n : null;
    }
    rateInput.addEventListener("input", () => {
      const value = validateDelay();
      if (value === null) {
        show("\u0414\u043E\u043F\u0443\u0441\u0442\u0438\u043C\u0430\u044F \u0437\u0430\u0434\u0435\u0440\u0436\u043A\u0430: 100\u201360000 \u043C\u0441");
        return;
      }
      if (value === currentDelay) return;
      currentDelay = value;
      if (state) void setMode(currentMode());
      show("\u041D\u043E\u0432\u0430\u044F \u0437\u0430\u0434\u0435\u0440\u0436\u043A\u0430 " + value + " \u043C\u0441 \u043F\u0440\u0438\u043C\u0435\u043D\u044F\u0435\u0442\u0441\u044F \u0431\u0435\u0437 \u0441\u0431\u0440\u043E\u0441\u0430 \u043E\u0447\u0435\u0440\u0435\u0434\u0438");
    });
    rateInput.addEventListener("change", () => {
      if (validateDelay() === null) rateInput.value = String(currentDelay);
    });
    async function dynamicDelay() {
      const started = performance.now();
      while (!paused && !stopped && !isClosed()) {
        const ms = currentDelay - (performance.now() - started);
        if (ms <= 0) break;
        await wait(Math.min(ms, 100));
      }
    }
    function audit(phase, rest = {}) {
      return chrome.runtime.sendMessage({ op: "vision-range-download-audit-v1", phase, ...rest });
    }
    async function waitForChrome(afterId, bytes, filename) {
      for (let i = 0; i < 240; i++) {
        const result = await audit("check", {
          after_id: afterId,
          byte_length: bytes,
          expected_filename: filename
        });
        if (result?.status === "RANGE_DOWNLOAD_COMPLETE") return;
        if (result?.status !== "RANGE_DOWNLOAD_PENDING")
          throw Error(result?.status || "MANUAL_ORDER_LIST_ZIP_AUDIT_FAILED");
        await wait(500);
      }
      throw Error("MANUAL_ORDER_LIST_ZIP_DOWNLOAD_TIMEOUT");
    }
    async function waitForPreviousOrder() {
      for (let i = 0; i < 210; i++) {
        const result = await chrome.runtime.sendMessage({
          op: "vision-approval-queue-status-v1"
        }).catch(() => null);
        if (result?.status !== "QUEUE_STATUS_OK")
          throw Error("MANUAL_ORDER_LIST_WORKER_STATUS_FAILED");
        if (!result.busy) return;
        await wait(1e3);
      }
      throw Error("MANUAL_ORDER_LIST_OLD_WORKER_BUSY");
    }
    async function commitDownloaded() {
      const info = state?.download;
      if (!info) return;
      const ids = info.order_ids || pending.map((x) => x.id);
      const selected = new Set(ids), rows = pending.filter((x) => selected.has(x.id));
      if (rows.length !== ids.length || !rows.length)
        throw Error("MANUAL_ORDER_LIST_DOWNLOAD_ROWS_MISSING");
      const updated = {
        ...state,
        download: null,
        archive_count: state.archive_count + 1,
        found_committed: state.found_committed + rows.length,
        files_committed: (state.files_committed || 0) + (Number.isInteger(info.verified_files) ? info.verified_files : rows.reduce((n, x) => n + (x.files || 0), 0)),
        last_archive: {
          filename: info.filename,
          bytes: info.bytes,
          orders: rows.length,
          files_verified: info.verified_files ?? null,
          files_missing: info.missing_files ?? null,
          entry_count: info.entry_count ?? null,
          confirmed_at: (/* @__PURE__ */ new Date()).toISOString(),
          storage: info.kind === "directory" ? "selected_directory" : "chrome_downloads",
          status: info.kind === "directory" ? "DIRECTORY_VERIFIED" : "CHROME_COMPLETE"
        },
        mode: currentMode()
      };
      await write(() => commitOrderFileArchive(updated, rows));
      state = updated;
      pending = pending.filter((x) => !selected.has(x.id));
      for (const id of ids) batch.discardOrder(id);
      saveBtn.disabled = running || !activeRows().length;
      lastError = null;
      show("ZIP \u2116" + state.archive_count + " \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D; \u043D\u043E\u0432\u0430\u044F \u043F\u0430\u0440\u0442\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430.");
    }
    async function resumePreparingZip() {
      const info = state?.download;
      if (info?.stage !== "preparing") return true;
      if (info.kind === "directory") {
        if (typeof globalThis.__visionArchiveSave !== "function")
          throw Error("VISION_DIRECTORY_ENGINE_REQUIRED");
        const selected2 = new Set(info.order_ids);
        const rows2 = pending.filter((row) => selected2.has(row.id));
        if (!rows2.length || rows2.length !== info.order_ids.length)
          throw Error("VISION_DIRECTORY_PENDING_ROWS_MISSING");
        const temp2 = new ApprovalBatchSession();
        for (const row of rows2) temp2.restoreOrder(row.id, row.transfers);
        const blob2 = temp2.finalize(rows2).blob;
        if (blob2.size !== info.bytes) throw Error("VISION_DIRECTORY_ZIP_SIZE_CHANGED");
        const saved = await globalThis.__visionArchiveSave(blob2, info.filename);
        if (saved?.status !== "VISION_LOCAL_ARCHIVE_VERIFIED")
          throw Error("VISION_DIRECTORY_FILE_UNCONFIRMED");
        await commitDownloaded();
        return true;
      }
      const check = await audit("check", {
        after_id: info.after_id,
        byte_length: info.bytes,
        expected_filename: info.filename
      });
      if (check?.status === "RANGE_DOWNLOAD_COMPLETE") {
        await commitDownloaded();
        return true;
      }
      if (check?.status === "RANGE_DOWNLOAD_PENDING" && check.matched > 0) {
        const next2 = { ...state, download: { ...info, stage: "started" } };
        await write(() => saveOrderFileStatus(next2));
        state = next2;
        for (const id of info.order_ids) batch.discardOrder(id);
        return true;
      }
      if (check?.status !== "RANGE_DOWNLOAD_PENDING")
        throw Error(check?.status || "VISION_ZIP_PREPARED_AUDIT_FAILED");
      const selected = new Set(info.order_ids);
      const rows = pending.filter((row) => selected.has(row.id));
      if (rows.length !== info.order_ids.length)
        throw Error("VISION_ZIP_PREPARED_ROWS_MISSING");
      const temp = new ApprovalBatchSession();
      for (const row of rows) temp.restoreOrder(row.id, row.transfers);
      const blob = temp.finalize(rows).blob;
      if (blob.size !== info.bytes) throw Error("VISION_ZIP_PREPARED_SIZE_CHANGED");
      const downloadId = await startExtensionZipDownload(blob, info.filename);
      const next = { ...state, download: {
        ...info,
        stage: "started",
        after_id: downloadId - 1
      } };
      await write(() => saveOrderFileStatus(next));
      state = next;
      for (const id of info.order_ids) batch.discardOrder(id);
      return true;
    }
    async function recoverDownload(waitForCompletion = false) {
      if (!state?.download) return true;
      try {
        if (state.download.kind === "directory")
          return await resumePreparingZip();
        await resumePreparingZip();
        if (!state.download) return true;
        const info = state.download;
        if (waitForCompletion) {
          await waitForChrome(info.after_id, info.bytes, info.filename);
          await commitDownloaded();
          return true;
        }
        const result = await audit("check", {
          after_id: info.after_id,
          byte_length: info.bytes,
          expected_filename: info.filename
        });
        if (result?.status === "RANGE_DOWNLOAD_COMPLETE") {
          await commitDownloaded();
          return true;
        }
        if (result?.status === "RANGE_DOWNLOAD_PENDING") return true;
        throw Error(result?.status || "MANUAL_ORDER_LIST_ZIP_AUDIT_FAILED");
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_ZIP_UNCONFIRMED");
        show("Chrome \u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0434\u0438\u043B ZIP. \u0414\u0430\u043D\u043D\u044B\u0435 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B; \u043F\u0440\u043E\u0432\u0435\u0440\u044C\u0442\u0435 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438.");
        return false;
      }
    }
    async function saveBatch(reason) {
      let rows = selectArchiveRows(activeRows());
      if (!rows.length) return true;
      if (state.download) {
        if (!await recoverDownload(true)) return false;
        rows = selectArchiveRows(activeRows());
        if (!rows.length) return true;
      }
      let result;
      try {
        result = batch.finalize(rows);
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_ZIP_INVALID");
        show();
        return false;
      }
      const filename = "vision-ai-list-part-" + pad(state.archive_count + 1) + "-" + rows[0].id + "-" + rows.at(-1).id + ".zip";
      try {
        const target = typeof globalThis.__visionArchiveSettings === "function" ? await globalThis.__visionArchiveSettings() : { ready: true, mode: "downloads" };
        if (!target.ready) throw Error(target.reason || "VISION_ARCHIVE_FOLDER_REQUIRED");
        if (target.mode === "directory") {
          const download2 = {
            kind: "directory",
            bytes: result.blob.size,
            filename,
            order_ids: rows.map((x) => x.id),
            stage: "preparing",
            verified_files: result.counts.verified_files,
            missing_files: result.counts.missing_files,
            entry_count: result.entry_count
          };
          const snapshot2 = { ...state, download: download2, mode: currentMode() };
          await write(() => saveOrderFileStatus(snapshot2));
          state = snapshot2;
          const saved = await globalThis.__visionArchiveSave(result.blob, filename);
          if (saved?.status !== "VISION_LOCAL_ARCHIVE_VERIFIED")
            throw Error("VISION_DIRECTORY_FILE_UNCONFIRMED");
          await commitDownloaded();
          return true;
        }
        const before = await audit("baseline");
        if (before?.status !== "RANGE_DOWNLOAD_BASELINE")
          throw Error("MANUAL_ORDER_LIST_DOWNLOAD_BASELINE");
        const download = {
          after_id: before.highest_id,
          bytes: result.blob.size,
          filename,
          order_ids: rows.map((x) => x.id),
          stage: "preparing",
          verified_files: result.counts.verified_files,
          missing_files: result.counts.missing_files,
          entry_count: result.entry_count
        };
        const snapshot = { ...state, download, mode: currentMode() };
        await write(() => saveOrderFileStatus(snapshot));
        state = snapshot;
        const downloadId = await startExtensionZipDownload(result.blob, filename);
        const started = { ...state, download: {
          ...download,
          stage: "started",
          after_id: downloadId - 1
        } };
        await write(() => saveOrderFileStatus(started));
        state = started;
        for (const row of rows) batch.discardOrder(row.id);
        show("ZIP \u043F\u0435\u0440\u0435\u0434\u0430\u043D Chrome (" + reason + "); \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u043A\u0443 \u043D\u043E\u0432\u044B\u0445 \u043D\u043E\u043C\u0435\u0440\u043E\u0432.");
        return true;
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_DOWNLOAD_FAILED");
        show("ZIP \u043F\u043E\u043A\u0430 \u043D\u0435 \u043D\u0430\u0447\u0430\u0442/\u043D\u0435 \u043F\u043E\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D: \u043F\u0430\u0440\u0442\u0438\u044F \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430 \u0432 IndexedDB");
        return false;
      }
    }
    async function manualSave() {
      if (running || !pending.length) return;
      if (state.download && !await recoverDownload(true)) return;
      while (activeRows().length) {
        if (!await saveBatch("\u0432\u0440\u0443\u0447\u043D\u0443\u044E")) return;
      }
      if (state.download) await recoverDownload(true);
    }
    async function importFile(file, remote = false, overwrite = false) {
      await init;
      if (running || getBusy()) {
        show("\u041D\u0435\u043B\u044C\u0437\u044F \u0437\u0430\u043C\u0435\u043D\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u043E \u0432\u0440\u0435\u043C\u044F \u0434\u0440\u0443\u0433\u043E\u0433\u043E \u0441\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u044F.");
        return;
      }
      if (!file) return;
      if (file.size > ORDER_LIST_MAX_BYTES) {
        lastError = "MANUAL_ORDER_LIST_FILE_TOO_LARGE";
        show();
        return;
      }
      let parsed;
      try {
        parsed = parseOrderListText(await file.text());
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_PARSE_FAILED");
        show();
        return;
      }
      if (state && (state.index > 0 || pending.length || state.found_committed > 0)) {
        if (remote && !overwrite) return { status: "VISION_IMPORT_REPLACE_REQUIRES_CONFIRMATION" };
        if (!remote && typeof globalThis.confirm === "function" && !globalThis.confirm(
          "\u0418\u043C\u043F\u043E\u0440\u0442 \u043D\u043E\u0432\u043E\u0433\u043E \u0444\u0430\u0439\u043B\u0430 \u0437\u0430\u043C\u0435\u043D\u0438\u0442 \u0442\u0435\u043A\u0443\u0449\u0438\u0439 \u0441\u043F\u0438\u0441\u043E\u043A \u0438 \u0435\u0433\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0451\u043D\u043D\u044B\u0439 \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u044D\u043A\u0441\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0439\u0442\u0435 \u0440\u0435\u0435\u0441\u0442\u0440 \u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 ZIP. \u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C?"
        )) return;
      }
      try {
        await writeChain.catch(() => {
        });
        const next = await importOrderFileQueue(parsed.numbers, file.name, currentDelay);
        state = next;
        queue = Uint32Array.from(parsed.numbers);
        pending = [];
        batch = new ApprovalBatchSession();
        checkedSession = 0;
        networkHealth = freshNetworkHealth();
        lastActivityAt = null;
        stopWithoutZip = false;
        lastError = null;
        restoreBlocked = false;
        paused = stopped = false;
        saveBtn.disabled = true;
        show("\u0424\u0430\u0439\u043B \u043F\u0440\u0438\u043D\u044F\u0442. \u0423\u043D\u0438\u043A\u0430\u043B\u044C\u043D\u044B\u0445 \u043D\u043E\u043C\u0435\u0440\u043E\u0432: " + parsed.numbers.length + "; \u0443\u0434\u0430\u043B\u0435\u043D\u043E \u043F\u043E\u0432\u0442\u043E\u0440\u043E\u0432: " + parsed.duplicates + ". \u041D\u0430\u0436\u043C\u0438\u0442\u0435 \xAB\u0421\u0442\u0430\u0440\u0442 / \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u043F\u043E \u0441\u043F\u0438\u0441\u043A\u0443\xBB.");
        return { status: "VISION_IMPORT_OK" };
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_IMPORT_FAILED");
        show();
      }
    }
    fileInput.addEventListener("change", () => {
      const file = fileInput.files?.[0];
      fileInput.value = "";
      void importFile(file);
    });
    async function reset(remote = false) {
      await init;
      if (running || getBusy()) return { status: "VISION_RESET_STOP_FIRST" };
      if (!remote && typeof globalThis.confirm === "function" && !globalThis.confirm(
        "\u0423\u0434\u0430\u043B\u0438\u0442\u044C \u0432\u0435\u0441\u044C \u0438\u043C\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u043D\u043D\u044B\u0439 \u0441\u043F\u0438\u0441\u043E\u043A, \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u044B \u0438 \u043A\u043E\u043D\u0442\u0440\u043E\u043B\u044C\u043D\u0443\u044E \u0442\u043E\u0447\u043A\u0443? \u0421\u043A\u0430\u0447\u0430\u043D\u043D\u044B\u0435 ZIP \u043E\u0441\u0442\u0430\u043D\u0443\u0442\u0441\u044F \u043D\u0430 \u0434\u0438\u0441\u043A\u0435."
      )) return;
      try {
        await writeChain.catch(() => {
        });
        await clearOrderFileQueue();
        queue = state = null;
        pending = [];
        batch = new ApprovalBatchSession();
        networkHealth = freshNetworkHealth();
        lastActivityAt = null;
        stopWithoutZip = false;
        checkedSession = 0;
        lastError = null;
        restoreBlocked = false;
        paused = stopped = false;
        saveBtn.disabled = true;
        show("\u0421\u043F\u0438\u0441\u043E\u043A \u0438 \u043F\u0440\u043E\u0433\u0440\u0435\u0441\u0441 \u043E\u0447\u0438\u0449\u0435\u043D\u044B");
        return { status: "VISION_RESET_COMPLETE" };
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_RESET_FAILED");
        show();
        return { status: "VISION_RESET_FAILED" };
      }
    }
    async function exportRegistry() {
      if (!state) {
        show("\u0421\u043F\u0438\u0441\u043E\u043A \u0435\u0449\u0451 \u043D\u0435 \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D");
        return;
      }
      try {
        const reg = await exportOrderFileRegistry();
        const json2 = {
          schema: "printcheck.vision.order-file-registry.v1",
          filename: state.filename,
          total: state.total,
          index: state.index,
          next_order: queue[state.index] || null,
          archives_completed: state.archive_count,
          found_committed: state.found_committed,
          found_archived: reg.found_archived,
          found_pending: pending.map(({ transfers, ...other }) => other),
          failed_orders: reg.failed_orders,
          training_ready: false,
          imported_at: state.imported_at
        };
        const u = URL.createObjectURL(new Blob(
          [JSON.stringify(json2, null, 2) + "\n"],
          { type: "application/json" }
        ));
        const a = el("a");
        a.href = u;
        a.download = "vision-ai-file-list-registry.json";
        document.body.append(a);
        a.click();
        a.remove();
        setTimeout(() => URL.revokeObjectURL(u), 15e3);
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_REGISTRY_FAILED");
        show();
      }
    }
    async function start() {
      if (running || getBusy() || isClosed()) return;
      await init;
      if (running || getBusy() || isClosed()) return;
      if (restoreBlocked) {
        show("\u0416\u0443\u0440\u043D\u0430\u043B \u043F\u043E\u0432\u0440\u0435\u0436\u0434\u0451\u043D. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435 \u0438\u0441\u0445\u043E\u0434\u043D\u044B\u0435 \u0434\u0430\u043D\u043D\u044B\u0435.");
        return;
      }
      if (!state || !queue) {
        show("\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 TXT \u0441\u043E \u0441\u043F\u0438\u0441\u043A\u043E\u043C");
        return;
      }
      if (!globalThis.__visionLocalTrustedTransport) {
        lastError = "MANUAL_MV3_TRANSPORT_REQUIRED";
        show();
        return;
      }
      if (typeof globalThis.__visionArchiveSettings === "function") {
        const target = await globalThis.__visionArchiveSettings().catch(() => ({ ready: false, reason: "VISION_ARCHIVE_FOLDER_CHECK_FAILED" }));
        if (!target.ready) {
          lastError = target.reason || "VISION_ARCHIVE_FOLDER_REQUIRED";
          show("\u041F\u0435\u0440\u0435\u0434 \u0441\u0442\u0430\u0440\u0442\u043E\u043C \u043E\u0431\u044F\u0437\u0430\u0442\u0435\u043B\u044C\u043D\u043E \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F ZIP.");
          return;
        }
      }
      const rate = validateDelay();
      if (rate === null) {
        lastError = "MANUAL_ORDER_LIST_DELAY_INVALID";
        show();
        return;
      }
      currentDelay = rate;
      if (state.index >= state.total && !pending.length && !state.download) {
        show("\u0412\u0441\u0435 \u043D\u043E\u043C\u0435\u0440\u0430 \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u044B.");
        return;
      }
      running = true;
      paused = stopped = false;
      setBusy(true);
      startBtn.disabled = resetBtn.disabled = saveBtn.disabled = true;
      pauseBtn.disabled = stopBtn.disabled = false;
      let message = "";
      try {
        if (state.download && !await recoverDownload())
          throw Error("MANUAL_ORDER_LIST_ZIP_UNCONFIRMED");
        await setMode("running");
        while (archiveBatchDue(activeRows())) {
          if (!await saveBatch("\u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043D\u0430\u044F \u043F\u0430\u0440\u0442\u0438\u044F"))
            throw Error("MANUAL_ORDER_LIST_ZIP_REQUIRES_REVIEW");
        }
        while (state.index < state.total && !paused && !stopped && !isClosed()) {
          const id = queue[state.index], order_number = String(id);
          stage = "checking_order";
          lastActivityAt = (/* @__PURE__ */ new Date()).toISOString();
          const measured = await controlledOrderProbe(id, (n) => probeTzForOrder(n, { explicitList: true }), { health: networkHealth });
          networkHealth = measured.health;
          const inspected = measured.result;
          if (measured.halt) {
            lastError = measured.reason;
            const blocked = {
              ...state,
              network: networkHealth,
              mode: "paused",
              last_activity_at: lastActivityAt
            };
            await write(() => saveOrderFileStatus(blocked));
            state = blocked;
            paused = true;
            show("\u041E\u0431\u043D\u0430\u0440\u0443\u0436\u0435\u043D \u043E\u0431\u0449\u0438\u0439 \u0441\u0431\u043E\u0439 \u0441\u0435\u0442\u0438. \u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0430.");
            break;
          }
          let record = null, failure = null;
          if (inspected.status === "TZ_APPROVED") {
            activeOrder2 = order_number;
            stage = "collecting_approvals";
            let collected;
            try {
              await waitForPreviousOrder();
              collected = await scanOrder(explicitListOrderUrl(id), true);
            } catch {
              collected = { status: "MANUAL_NATIVE_APPROVAL_QUEUE_FAILED" };
            } finally {
              activeOrder2 = null;
            }
            if (collected?.status === "COMPLETE" && collected.final_evidence_saved === true) {
              try {
                record = {
                  id: order_number,
                  order_number,
                  collected_at: (/* @__PURE__ */ new Date()).toISOString(),
                  status: "TZ_APPROVED",
                  native_status_id: "59",
                  eligible_articles: collected.eligible_articles || 0,
                  verified_articles: collected.verified_articles || 0,
                  files: collected.files || 0,
                  transfers: batch.exportOrder(order_number)
                };
              } catch (error) {
                failure = {
                  id: order_number,
                  phase: "native_approval",
                  reason: String(error?.message || "MANUAL_ORDER_LIST_MISSING_EVIDENCE")
                };
              }
            } else {
              failure = {
                id: order_number,
                phase: "native_approval",
                reason: String(collected?.status || "MANUAL_APPROVAL_COLLECTION_INCOMPLETE")
              };
            }
          } else if (inspected.status !== "TZ_NOT_APPROVED" && inspected.status !== "ORDER_NOT_FOUND") {
            if (!isRecoverableRangeFailure(inspected.status)) {
              lastError = "MANUAL_ORDER_LIST_GLOBAL_" + inspected.status;
              break;
            }
            failure = {
              id: order_number,
              phase: "order_card",
              reason: inspected.status,
              ...Number.isInteger(inspected.http_status) ? { http_status: inspected.http_status } : {}
            };
          }
          const next = {
            ...state,
            index: state.index + 1,
            failed_count: state.failed_count + (failure ? 1 : 0),
            delay_ms: currentDelay,
            mode: currentMode(),
            network: networkHealth,
            browser_scans: (state.browser_scans || 0) + (inspected.status === "TZ_APPROVED" ? 1 : 0),
            last_activity_at: (/* @__PURE__ */ new Date()).toISOString()
          };
          await write(() => saveOrderFileProgress(next, record, failure));
          state = next;
          lastActivityAt = next.last_activity_at;
          if (record) pending.push(record);
          else batch.discardOrder(order_number);
          checkedSession++;
          if (state.download && !await recoverDownload(false)) break;
          if (archiveBatchDue(activeRows())) {
            const bySize = activeBytes() >= SOFT_BATCH_PAYLOAD_LIMIT;
            if (!await saveBatch(bySize ? "\u043F\u0440\u0435\u0434\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u0435\u043B\u044C\u043D\u043E\u0435 \u043E\u0433\u0440\u0430\u043D\u0438\u0447\u0435\u043D\u0438\u0435 \u0440\u0430\u0437\u043C\u0435\u0440\u0430" : "100 \u0443\u0442\u0432\u0435\u0440\u0436\u0434\u0451\u043D\u043D\u044B\u0445 \u0437\u0430\u043A\u0430\u0437\u043E\u0432")) break;
          }
          show("\u041F\u043E\u0441\u043B\u0435\u0434\u043D\u0438\u0439 \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440: " + order_number + " \u2014 " + (failure ? failure.reason : inspected.status));
          if (!paused && !stopped) await dynamicDelay();
        }
        if ((stopped && !stopWithoutZip || state.index >= state.total) && pending.length) {
          while (activeRows().length) {
            if (!await saveBatch(stopped ? "\u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043A\u0430" : "\u043E\u043A\u043E\u043D\u0447\u0430\u043D\u0438\u0435 \u0444\u0430\u0439\u043B\u0430")) {
              paused = true;
              break;
            }
          }
          if (state.download && !await recoverDownload(true)) paused = true;
        }
        message = lastError ? "\u041E\u0421\u0422\u0410\u041D\u041E\u0412\u041B\u0415\u041D\u041E: " + lastError : paused ? "\u041F\u0410\u0423\u0417\u0410. \u041C\u043E\u0436\u043D\u043E \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C. \u0414\u0430\u043D\u043D\u044B\u0435 \u043F\u0430\u0440\u0442\u0438\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B." : stopped ? stopWithoutZip ? "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u041A\u0443\u0440\u0441\u043E\u0440 \u0438 \u0444\u0430\u0439\u043B\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B \u0432 IndexedDB; ZIP \u2014 \u043E\u0442\u0434\u0435\u043B\u044C\u043D\u043E." : "\u041E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E. \u0420\u0435\u0435\u0441\u0442\u0440 \u0438 \u0430\u0440\u0445\u0438\u0432 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u044B." : state.index >= state.total ? "\u0421\u043F\u0438\u0441\u043E\u043A \u043F\u043E\u043B\u043D\u043E\u0441\u0442\u044C\u044E \u043F\u0440\u043E\u0432\u0435\u0440\u0435\u043D." : "\u0421\u043A\u0430\u043D\u0438\u0440\u043E\u0432\u0430\u043D\u0438\u0435 \u043F\u0440\u0435\u0440\u0432\u0430\u043D\u043E.";
      } catch (error) {
        lastError = String(error?.message || "MANUAL_ORDER_LIST_SCAN_FAILED");
        message = "\u041E\u0421\u0422\u0410\u041D\u041E\u0412\u041A\u0410 \u041F\u041E \u041E\u0428\u0418\u0411\u041A\u0415: " + lastError;
      } finally {
        activeOrder2 = null;
        running = false;
        setBusy(false);
        stage = "idle";
        if (state) await setMode(stopped || state.index >= state.total ? "stopped" : "paused");
        startBtn.disabled = resetBtn.disabled = false;
        pauseBtn.disabled = stopBtn.disabled = true;
        saveBtn.disabled = !pending.length;
        refreshControls();
        show(message);
      }
    }
    init = (async () => {
      const saved = await loadOrderFileState();
      if (!saved) return false;
      state = saved.state;
      queue = saved.queue;
      if (state.download && !Array.isArray(state.download.order_ids)) {
        state = { ...state, download: {
          ...state.download,
          order_ids: saved.pending.map((x) => x.id)
        } };
        await saveOrderFileStatus(state);
      }
      currentDelay = state.delay_ms;
      rateInput.value = String(currentDelay);
      networkHealth = normalizeNetworkHealth(state.network);
      lastActivityAt = state.last_activity_at || state.updated_at || null;
      if (saved.pending.some((x) => !Array.isArray(x.transfers) || !x.transfers.length))
        throw Error("MANUAL_ORDER_LIST_PENDING_INVALID");
      batch = new ApprovalBatchSession();
      for (const record of saved.pending) {
        if (!state.download?.order_ids?.includes(record.id) || state.download?.stage === "preparing")
          batch.restoreOrder(record.id, record.transfers);
        pending.push(record);
      }
      saveBtn.disabled = !pending.length;
      show("\u041E\u0447\u0435\u0440\u0435\u0434\u044C \u0438 \u043D\u0435\u043F\u043E\u043B\u043D\u0430\u044F ZIP-\u043F\u0430\u0440\u0442\u0438\u044F \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u044B \u043F\u043E\u0441\u043B\u0435 \u043E\u0431\u043D\u043E\u0432\u043B\u0435\u043D\u0438\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u044B.");
      return state.mode === "running" || state.mode === "downloading";
    })().catch((error) => {
      restoreBlocked = true;
      lastError = String(error?.message || "MANUAL_ORDER_LIST_RESTORE_FAILED");
      show("\u041D\u0435 \u0443\u0434\u0430\u043B\u043E\u0441\u044C \u0432\u043E\u0441\u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u044C \u043E\u0447\u0435\u0440\u0435\u0434\u044C. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043E\u0447\u0438\u0449\u0435\u043D\u044B.");
      return false;
    });
    init.then((auto) => {
      if (auto && !isClosed()) void start();
    });
    return {
      element: root,
      get activeOrder() {
        return activeOrder2;
      },
      get running() {
        return running;
      },
      receive: (message, expectedOrder) => batch.receive(message, expectedOrder),
      remote: async (action, payload = {}) => {
        if (action === "status") {
          await init;
          let archive_audit = null;
          if (state?.download) {
            const d = state.download;
            try {
              archive_audit = await audit("check", {
                after_id: d.after_id,
                byte_length: d.bytes,
                expected_filename: d.filename
              });
            } catch {
              archive_audit = { status: "VISION_DOWNLOAD_AUDIT_UNAVAILABLE" };
            }
          }
          return {
            mode: "file",
            running,
            paused,
            stopped,
            archive_audit,
            download_details: state?.download ? {
              filename: state.download.filename,
              bytes: state.download.bytes,
              files_verified: state.download.verified_files ?? null,
              files_missing: state.download.missing_files ?? null
            } : null,
            filename: state?.filename || null,
            total: state?.total || 0,
            checked: state?.index || 0,
            progress_percent: state?.total ? Math.floor(100 * state.index / state.total) : 0,
            last_activity_at: lastActivityAt || state?.updated_at || null,
            phase: stage,
            network: { ...networkHealth },
            last_archive: state?.last_archive || null,
            files_archived: state?.files_committed || 0,
            files_staged: pending.reduce((n, x) => n + (x.files || 0), 0),
            direct_http_checks: networkHealth.attempts,
            browser_scans: state?.browser_scans || 0,
            next_order: queue && state?.index < state?.total ? String(queue[state.index]) : null,
            archives: state?.archive_count || 0,
            found: state?.found_committed || 0,
            pending: pending.length,
            downloading: !!state?.download,
            errors: state?.failed_count || 0,
            delay_ms: currentDelay,
            blocked: restoreBlocked,
            error: lastError
          };
        }
        if (action === "import") {
          if (typeof payload.text !== "string" || payload.text.length > 2e7 || typeof payload.filename !== "string")
            throw Error("MANUAL_ORDER_LIST_REMOTE_IMPORT_INVALID");
          const raw = payload.text;
          const file = {
            name: payload.filename.slice(0, 120),
            size: new TextEncoder().encode(raw).length,
            text: async () => raw
          };
          const result = await importFile(file, true, payload.overwrite === true);
          return result || { status: lastError || "VISION_IMPORT_NOT_COMPLETED" };
        }
        if (action === "delay") {
          if (!acceptedRate(payload.value)) throw Error("MANUAL_ORDER_LIST_DELAY_INVALID");
          rateInput.value = String(payload.value);
          rateInput.dispatchEvent(new Event("input"));
          return { status: "VISION_DELAY_UPDATED" };
        }
        if (action === "start") {
          if (running || getBusy()) return { status: "VISION_SCAN_ALREADY_RUNNING" };
          if (restoreBlocked) return { status: "VISION_SCAN_RESTORE_BLOCKED", reason: lastError };
          if (!state || !queue) return { status: "VISION_SCAN_TXT_REQUIRED" };
          if (typeof globalThis.__visionArchiveSettings === "function") {
            const place = await globalThis.__visionArchiveSettings().catch(() => ({ ready: false, reason: "VISION_ARCHIVE_FOLDER_CHECK_FAILED" }));
            if (!place.ready) return { status: place.reason || "VISION_ARCHIVE_FOLDER_REQUIRED" };
          }
          void start();
          return { status: "VISION_SCAN_START_REQUESTED" };
        }
        if (action === "pause") {
          pauseBtn.click();
          return { status: "VISION_SCAN_PAUSE_REQUESTED" };
        }
        if (action === "stop") {
          stopped = true;
          stopWithoutZip = false;
          await setMode("stopped");
          if (!running) await manualSave();
          return { status: "VISION_SCAN_STOP_REQUESTED" };
        }
        if (action === "save") {
          saveBtn.click();
          return { status: "VISION_SCAN_ZIP_SAVE_REQUESTED" };
        }
        if (action === "reset") {
          if (payload.confirmed !== true) return { status: "VISION_RESET_CONFIRMATION_REQUIRED" };
          return await reset(true);
        }
        if (action === "export") {
          exportBtn.click();
          return { status: "VISION_REGISTRY_EXPORT_REQUESTED" };
        }
        return { status: "VISION_REMOTE_ACTION_DENIED" };
      },
      requestPause: () => {
        paused = true;
        void setMode("paused");
      },
      requestStop: () => {
        stopped = true;
        stopWithoutZip = false;
        void setMode("stopped");
        if (!running) void manualSave();
      }
    };
  }

  // vision/orders/extension/archive-local-files.mjs
  var DB_NAME = "vision-ai-selected-archive-folder-v1";
  var STORE_NAME = "directory";
  function storeDirectory(handle) {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE_NAME))
          req.result.createObjectStore(STORE_NAME);
      };
      req.onerror = () => reject(Error("VISION_FOLDER_DATABASE_OPEN_FAILED"));
      req.onsuccess = () => {
        const db = req.result;
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).put(handle, "selected");
        tx.oncomplete = () => {
          db.close();
          resolve();
        };
        tx.onerror = () => {
          db.close();
          reject(Error("VISION_FOLDER_STORE_FAILED"));
        };
      };
    });
  }
  function readDirectory() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => {
        if (!req.result.objectStoreNames.contains(STORE_NAME))
          req.result.createObjectStore(STORE_NAME);
      };
      req.onerror = () => reject(Error("VISION_FOLDER_DATABASE_OPEN_FAILED"));
      req.onsuccess = () => {
        const db = req.result, tx = db.transaction(STORE_NAME, "readonly");
        const request = tx.objectStore(STORE_NAME).get("selected");
        tx.oncomplete = () => {
          db.close();
          resolve(request.result || null);
        };
        tx.onerror = () => {
          db.close();
          reject(Error("VISION_FOLDER_READ_FAILED"));
        };
      };
    });
  }
  async function chooseArchiveDirectory() {
    if (typeof globalThis.showDirectoryPicker !== "function")
      throw Error("VISION_DIRECTORY_PICKER_UNAVAILABLE");
    const handle = await globalThis.showDirectoryPicker({ mode: "readwrite" });
    if (!handle || handle.kind !== "directory")
      throw Error("VISION_DIRECTORY_SELECTION_INVALID");
    const permission = await handle.queryPermission({ mode: "readwrite" });
    if (permission !== "granted") {
      const granted = await handle.requestPermission({ mode: "readwrite" });
      if (granted !== "granted") throw Error("VISION_DIRECTORY_PERMISSION_DENIED");
    }
    await storeDirectory(handle);
    return { name: handle.name, permission: "granted" };
  }
  async function archiveDirectoryStatus() {
    const handle = await readDirectory();
    if (!handle || handle.kind !== "directory")
      return { ready: false, name: null, reason: "VISION_DIRECTORY_NOT_SELECTED" };
    const permission = await handle.queryPermission({ mode: "readwrite" });
    return {
      ready: permission === "granted",
      name: handle.name,
      reason: permission === "granted" ? null : "VISION_DIRECTORY_PERMISSION_REQUIRED"
    };
  }
  var hex = (bytes) => Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  var sha = async (blob) => hex(new Uint8Array(await crypto.subtle.digest(
    "SHA-256",
    await blob.arrayBuffer()
  )));
  async function matchingFile(directory, name, blob) {
    try {
      const file = await (await directory.getFileHandle(name)).getFile();
      if (file.size !== blob.size) return false;
      return await sha(file) === await sha(blob);
    } catch {
      return false;
    }
  }
  async function saveOrderToDirectory(blob, filename) {
    if (!(blob instanceof Blob) || blob.size < 100 || blob.size > 2e8 || !/^vision-ai-list-part-\d{5}-\d{7}-\d{7}\.zip$/.test(filename))
      throw Error("VISION_LOCAL_ARCHIVE_ARGS_INVALID");
    const handle = await readDirectory();
    if (!handle || await handle.queryPermission({ mode: "readwrite" }) !== "granted")
      throw Error("VISION_DIRECTORY_PERMISSION_REQUIRED");
    let selected = filename, previouslySaved = false;
    for (let i = 0; i < 1e4; i++) {
      selected = i === 0 ? filename : filename.replace(/\.zip$/, ".copy-" + i + ".zip");
      if (await matchingFile(handle, selected, blob)) {
        previouslySaved = true;
        break;
      }
      try {
        await handle.getFileHandle(selected);
      } catch {
        break;
      }
      if (i === 9999) throw Error("VISION_DIRECTORY_NAME_EXHAUSTED");
    }
    if (!previouslySaved) {
      const entry = await handle.getFileHandle(selected, { create: true });
      const writer = await entry.createWritable({ keepExistingData: false });
      try {
        await writer.write(blob);
        await writer.close();
      } catch (error) {
        try {
          await writer.abort();
        } catch {
        }
        throw error;
      }
    }
    const result = await (await handle.getFileHandle(selected)).getFile();
    if (result.size !== blob.size || await sha(result) !== await sha(blob))
      throw Error("VISION_DIRECTORY_ARCHIVE_VERIFY_FAILED");
    const hash = await sha(blob);
    if (typeof globalThis.VisionArchives?.recordLocal === "function") {
      await globalThis.VisionArchives.recordLocal({
        filename: selected,
        bytes: blob.size,
        sha256: hash,
        folder: handle.name
      });
    }
    return {
      status: "VISION_LOCAL_ARCHIVE_VERIFIED",
      filename: selected,
      bytes: blob.size,
      sha256: hash,
      folder: handle.name
    };
  }

  // vision/orders/extension/scanner-host-entry.mjs
  var mount = document.querySelector("#vision-scanner-host");
  if (!mount || location.href !== chrome.runtime.getURL("scanner-host.html"))
    throw Error("VISION_ENGINE_HOST_UNTRUSTED");
  if (typeof globalThis.__visionLocalTrustedTransport !== "function")
    throw Error("VISION_ENGINE_TRANSPORT_MISSING");
  var busy = false;
  var activeOrder = null;
  var folderButton = document.querySelector("#vision-choose-archive-folder");
  var folderStatus = document.querySelector("#vision-archive-folder-status");
  async function updateFolderStatus() {
    const selected = await archiveDirectoryStatus().catch(() => ({ ready: false }));
    const config = await chrome.runtime.sendMessage({
      op: "vision-archive-settings-v1",
      action: "get"
    }).catch(() => ({}));
    const mode = config?.mode || "downloads";
    if (folderStatus) folderStatus.textContent = mode === "directory" ? "\u0412\u044B\u0431\u0440\u0430\u043D\u043D\u0430\u044F \u043F\u0430\u043F\u043A\u0430: " + (selected.name || "\u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430") + " \xB7 " + (selected.ready ? "\u0437\u0430\u043F\u0438\u0441\u044C \u0440\u0430\u0437\u0440\u0435\u0448\u0435\u043D\u0430" : "\u0422\u0420\u0415\u0411\u0423\u0415\u0422\u0421\u042F \u0412\u042B\u0411\u0420\u0410\u0422\u042C \u0417\u0410\u041D\u041E\u0412\u041E") : config.configured ? "\u0410\u0432\u0442\u043E\u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0435: \xAB\u0417\u0430\u0433\u0440\u0443\u0437\u043A\u0438\xBB Chrome / " + config.folder : "\u041C\u0435\u0441\u0442\u043E \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u044F \u043D\u0435 \u0437\u0430\u0434\u0430\u043D\u043E. \u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0432\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u043F\u0430\u043F\u043A\u0443.";
  }
  if (folderButton) folderButton.addEventListener("click", async () => {
    try {
      const chosen = await chooseArchiveDirectory();
      const result = await chrome.runtime.sendMessage({
        op: "vision-archive-settings-v1",
        action: "set",
        payload: { mode: "directory", folder: chosen.name }
      });
      if (result?.status !== "VISION_ARCHIVE_SETTINGS_SAVED")
        throw Error(result?.status || "VISION_ARCHIVE_CONFIGURATION_FAILED");
      await updateFolderStatus();
    } catch (error) {
      folderStatus.textContent = "\u041F\u0430\u043F\u043A\u0430 \u043D\u0435 \u0432\u044B\u0431\u0440\u0430\u043D\u0430: " + String(error?.message || "UNKNOWN");
    }
  });
  globalThis.__visionArchiveSettings = async () => {
    const config = await chrome.runtime.sendMessage({
      op: "vision-archive-settings-v1",
      action: "get"
    });
    if (config?.configured !== true)
      return { ready: false, reason: "VISION_ARCHIVE_FOLDER_NOT_CONFIGURED" };
    if (config.mode === "downloads")
      return { ready: true, mode: "downloads", folder: config.folder };
    if (config.mode === "directory") {
      const status = await archiveDirectoryStatus();
      return status.ready ? { ready: true, mode: "directory", folder: status.name } : { ready: false, reason: status.reason };
    }
    return { ready: false, reason: "VISION_ARCHIVE_FOLDER_NOT_CONFIGURED" };
  };
  globalThis.__visionArchiveSave = saveOrderToDirectory;
  void updateFolderStatus();
  var controller = makeApprovalFileListController({
    getBusy: () => busy,
    setBusy: (value) => {
      busy = !!value;
    },
    isClosed: () => false,
    scanOrder: async (url, require_tz_approved) => {
      activeOrder = new URL(url).pathname.split("/").at(-1);
      try {
        return await chrome.runtime.sendMessage({
          op: "vision-approval-order-queue-v1",
          order_url: url,
          require_tz_approved: require_tz_approved === true
        });
      } finally {
        activeOrder = null;
      }
    }
  });
  mount.append(controller.element);
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender?.id !== chrome.runtime.id || sender?.tab || !message) return false;
    if (message.op === "vision-engine-command-v1") {
      if (message.mode !== "file" || ![
        "status",
        "import",
        "start",
        "pause",
        "stop",
        "reset",
        "save",
        "export",
        "delay"
      ].includes(message.action)) {
        respond({ status: "VISION_ENGINE_COMMAND_DENIED" });
        return false;
      }
      controller.remote(message.action, message.payload || {}).then(respond, (error) => respond({
        status: "VISION_ENGINE_COMMAND_FAILED",
        reason: String(error?.message || "UNKNOWN").slice(0, 120)
      }));
      return true;
    }
    if (message.op === "vision-approval-batch-accept-v1") {
      if (!activeOrder || String(message.order_number) !== activeOrder) {
        respond({ status: "MANUAL_BATCH_HOST_ORDER_MISMATCH" });
        return false;
      }
      respond(controller.receive(message, activeOrder));
      return false;
    }
    return false;
  });
})();
